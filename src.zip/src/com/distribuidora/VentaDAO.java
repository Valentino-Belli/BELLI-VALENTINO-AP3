package com.distribuidora;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    // Registra la venta, sus detalles, resta el stock y guarda el historial.
    public int registrarVenta(Venta venta) throws SQLException {
        if (venta.getDetalles() == null || venta.getDetalles().isEmpty()) {
            throw new SQLException("La venta no tiene productos.");
        }
        for (DetalleVenta detalle : venta.getDetalles()) {
            if (detalle.getCantidad() <= 0
                    || detalle.getPrecioUnitario().compareTo(BigDecimal.ZERO) <= 0) {
                throw new SQLException("Todos los productos deben tener cantidad y precio mayores a 0.");
            }
        }
        String sqlVenta = """
            INSERT INTO venta (fecha, idEstadoVenta, idUsuario, idCliente)
            VALUES (?, ?, ?, ?)
            """;
        String sqlDetalle = """
            INSERT INTO detalle_venta
                (idVenta, idProducto, cantidad, precioUnitario, precioTotal)
            VALUES (?, ?, ?, ?, ?)
            """;
        String sqlStock = """
            UPDATE producto
            SET stockActual = stockActual - ?
            WHERE idProducto = ?
              AND stockActual >= ?
            """;
        String sqlHistorial = """
            INSERT INTO historial
                (fecha, idProducto, cantidad, tipoMovimiento)
            VALUES (CURRENT_TIMESTAMP, ?, ?, ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar()) {
            conexion.setAutoCommit(false);
            try {
                int idVenta;
                try (PreparedStatement sentencia = conexion.prepareStatement(
                        sqlVenta, Statement.RETURN_GENERATED_KEYS)) {
                    sentencia.setDate(1, Date.valueOf(venta.getFecha()));
                    sentencia.setInt(2, venta.getIdEstadoVenta());
                    sentencia.setInt(3, venta.getIdUsuario());
                    sentencia.setInt(4, venta.getIdCliente());
                    sentencia.executeUpdate();
                    try (ResultSet claves = sentencia.getGeneratedKeys()) {
                        if (!claves.next()) {
                            throw new SQLException("No se pudo obtener el id de la venta.");
                        }
                        idVenta = claves.getInt(1);
                    }
                }
                for (DetalleVenta detalle : venta.getDetalles()) {
                    int filas;
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlStock)) {
                        sentencia.setInt(1, detalle.getCantidad());
                        sentencia.setInt(2, detalle.getIdProducto());
                        sentencia.setInt(3, detalle.getCantidad());
                        filas = sentencia.executeUpdate();
                    }
                    if (filas == 0) {
                        throw new SQLException("Stock insuficiente (o producto inexistente) "
                                + "para el producto con id " + detalle.getIdProducto() + ".");
                    }
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlDetalle)) {
                        sentencia.setInt(1, idVenta);
                        sentencia.setInt(2, detalle.getIdProducto());
                        sentencia.setInt(3, detalle.getCantidad());
                        sentencia.setBigDecimal(4, detalle.getPrecioUnitario());
                        sentencia.setBigDecimal(5, detalle.getPrecioTotal());
                        sentencia.executeUpdate();
                    }
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlHistorial)) {
                        sentencia.setInt(1, detalle.getIdProducto());
                        sentencia.setInt(2, detalle.getCantidad());
                        sentencia.setString(3, "Egreso");
                        sentencia.executeUpdate();
                    }
                }
                conexion.commit();
                venta.setIdVenta(idVenta);
                return idVenta;
            } catch (SQLException e) {
                conexion.rollback();
                throw e;
            } finally {
                conexion.setAutoCommit(true);
            }
        }
    }

    // Anula una venta PENDIENTE: cambia el estado, devuelve el stock y guarda el historial.
    public int anularVenta(int idVenta, int idEstadoPendiente,
                           int idEstadoAnulada) throws SQLException {
        String sqlEstadoActual = "SELECT idEstadoVenta FROM venta WHERE idVenta = ? FOR UPDATE";
        String sqlDetalles = """
            SELECT idProducto, cantidad
            FROM detalle_venta
            WHERE idVenta = ?
            """;
        String sqlStock = """
            UPDATE producto
            SET stockActual = stockActual + ?
            WHERE idProducto = ?
            """;
        String sqlHistorial = """
            INSERT INTO historial
                (fecha, idProducto, cantidad, tipoMovimiento)
            VALUES (CURRENT_TIMESTAMP, ?, ?, ?)
            """;
        String sqlEstado = "UPDATE venta SET idEstadoVenta = ? WHERE idVenta = ?";
        try (Connection conexion = ConexionMySQL.conectar()) {
            conexion.setAutoCommit(false);
            try {
                try (PreparedStatement sentencia = conexion.prepareStatement(sqlEstadoActual)) {
                    sentencia.setInt(1, idVenta);
                    try (ResultSet resultado = sentencia.executeQuery()) {
                        if (!resultado.next()
                                || resultado.getInt("idEstadoVenta") != idEstadoPendiente) {
                            conexion.rollback();
                            return 0;
                        }
                    }
                }
                List<DetalleVenta> detalles = new ArrayList<>();
                try (PreparedStatement sentencia = conexion.prepareStatement(sqlDetalles)) {
                    sentencia.setInt(1, idVenta);
                    try (ResultSet resultado = sentencia.executeQuery()) {
                        while (resultado.next()) {
                            DetalleVenta detalle = new DetalleVenta();
                            detalle.setIdProducto(resultado.getInt("idProducto"));
                            detalle.setCantidad(resultado.getInt("cantidad"));
                            detalles.add(detalle);
                        }
                    }
                }
                for (DetalleVenta detalle : detalles) {
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlStock)) {
                        sentencia.setInt(1, detalle.getCantidad());
                        sentencia.setInt(2, detalle.getIdProducto());
                        sentencia.executeUpdate();
                    }
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlHistorial)) {
                        sentencia.setInt(1, detalle.getIdProducto());
                        sentencia.setInt(2, detalle.getCantidad());
                        sentencia.setString(3, "Ingreso");
                        sentencia.executeUpdate();
                    }
                }
                int filas;
                try (PreparedStatement sentencia = conexion.prepareStatement(sqlEstado)) {
                    sentencia.setInt(1, idEstadoAnulada);
                    sentencia.setInt(2, idVenta);
                    filas = sentencia.executeUpdate();
                }
                conexion.commit();
                return filas;
            } catch (SQLException e) {
                conexion.rollback();
                throw e;
            } finally {
                conexion.setAutoCommit(true);
            }
        }
    }

    // Confirma una venta pendiente
    public int confirmarVenta(int idVenta, int idEstadoPendiente,
                              int idEstadoConfirmada) throws SQLException {
        String sql = """
            UPDATE venta
            SET idEstadoVenta = ?
            WHERE idVenta = ?
              AND idEstadoVenta = ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idEstadoConfirmada);
            sentencia.setInt(2, idVenta);
            sentencia.setInt(3, idEstadoPendiente);
            return sentencia.executeUpdate();
        }
    }

    // Cambia el estado de una venta (sin tocar el stock)
    public int cambiarEstado(int idVenta, int idEstadoVenta) throws SQLException {
        String sql = "UPDATE venta SET idEstadoVenta = ? WHERE idVenta = ?";
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idEstadoVenta);
            sentencia.setInt(2, idVenta);
            return sentencia.executeUpdate();
        }
    }

    // Pide a la base de datos los estados de venta existentes
    public List<EstadoVenta> listarEstados() throws SQLException {
        List<EstadoVenta> estados = new ArrayList<>();
        String sql = """
            SELECT idEstadoVenta, nombreEstado
            FROM estado_venta
            ORDER BY idEstadoVenta
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {
            while (resultado.next()) {
                estados.add(new EstadoVenta(
                        resultado.getInt("idEstadoVenta"),
                        resultado.getString("nombreEstado")
                ));
            }
        }
        return estados;
    }

    // Lista las ventas para la paginación de las tablas, respetando filtros
    public List<Venta> listarPagina(
            int limite, int offset, String filtro) throws SQLException {
        List<Venta> ventas = new ArrayList<>();
        String sql = """
            SELECT v.idVenta, v.fecha, v.idEstadoVenta, v.idUsuario, v.idCliente,
                   e.nombreEstado,
                   CONCAT(c.nombreCliente, ' ', c.apellidoCliente) AS cliente,
                   c.dni AS dniCliente,
                   u.username
            FROM venta v
            INNER JOIN estado_venta e ON v.idEstadoVenta = e.idEstadoVenta
            INNER JOIN cliente c ON v.idCliente = c.idCliente
            INNER JOIN usuario u ON v.idUsuario = u.idUsuario
            WHERE (? = ''
                   OR CONCAT(c.nombreCliente, ' ', c.apellidoCliente) LIKE ?
                   OR c.nombreCliente LIKE ?
                   OR c.apellidoCliente LIKE ?
                   OR c.dni LIKE ?)
            ORDER BY v.idVenta DESC
            LIMIT ? OFFSET ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            for (int i = 2; i <= 5; i++) {
                sentencia.setString(i, patron);
            }
            sentencia.setInt(6, limite);
            sentencia.setInt(7, offset);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    Venta venta = new Venta();
                    venta.setIdVenta(resultado.getInt("idVenta"));
                    venta.setFecha(resultado.getDate("fecha").toLocalDate());
                    venta.setIdEstadoVenta(resultado.getInt("idEstadoVenta"));
                    venta.setIdUsuario(resultado.getInt("idUsuario"));
                    venta.setIdCliente(resultado.getInt("idCliente"));
                    venta.setNombreEstado(resultado.getString("nombreEstado"));
                    venta.setNombreCliente(resultado.getString("cliente"));
                    venta.setDniCliente(resultado.getString("dniCliente"));
                    venta.setNombreUsuario(resultado.getString("username"));
                    ventas.add(venta);
                }
            }
        }
        return ventas;
    }

    // Calcula cuantas ventas hay para determinar la cantidad de páginas
    public int contarVentas(String filtro) throws SQLException {
        String sql = """
            SELECT COUNT(*)
            FROM venta v
            INNER JOIN cliente c ON v.idCliente = c.idCliente
            WHERE (? = ''
                   OR CONCAT(c.nombreCliente, ' ', c.apellidoCliente) LIKE ?
                   OR c.nombreCliente LIKE ?
                   OR c.apellidoCliente LIKE ?
                   OR c.dni LIKE ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            for (int i = 2; i <= 5; i++) {
                sentencia.setString(i, patron);
            }
            try (ResultSet resultado = sentencia.executeQuery()) {
                resultado.next();
                return resultado.getInt(1);
            }
        }
    }

    // Recupera los detalles (productos) de una venta
    public List<DetalleVenta> listarDetalles(int idVenta) throws SQLException {
        List<DetalleVenta> detalles = new ArrayList<>();
        String sql = """
            SELECT d.idDetalleVenta, d.idVenta, d.idProducto, d.cantidad,
                   d.precioUnitario, d.precioTotal, p.descripcion
            FROM detalle_venta d
            INNER JOIN producto p
                ON d.idProducto = p.idProducto
            WHERE d.idVenta = ?
            ORDER BY d.idDetalleVenta
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idVenta);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    DetalleVenta detalle = new DetalleVenta();
                    detalle.setIdDetalleVenta(resultado.getInt("idDetalleVenta"));
                    detalle.setIdVenta(resultado.getInt("idVenta"));
                    detalle.setIdProducto(resultado.getInt("idProducto"));
                    detalle.setCantidad(resultado.getInt("cantidad"));
                    detalle.setPrecioUnitario(resultado.getBigDecimal("precioUnitario"));
                    detalle.setPrecioTotal(resultado.getBigDecimal("precioTotal"));
                    detalle.setDescripcionProducto(resultado.getString("descripcion"));
                    detalles.add(detalle);
                }
            }
        }
        return detalles;
    }
}
