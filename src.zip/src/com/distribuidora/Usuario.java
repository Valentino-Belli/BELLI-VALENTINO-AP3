package com.distribuidora;

public class Usuario {

    private int idUsuario;
    private String username;
    private String contraseña;
    private String nombreUsuario;
    private String apellidoUsuario;
    private int idRolUsuario;
    private String nombreRol;
    private boolean usuarioActivo;

    public Usuario() {
    }

    public Usuario(int idUsuario, String username, String contraseña,
                   String nombreUsuario, String apellidoUsuario,
                   int idRolUsuario, boolean usuarioActivo) {
        this.idUsuario = idUsuario;
        this.username = username;
        this.contraseña = contraseña;
        this.nombreUsuario = nombreUsuario;
        this.apellidoUsuario = apellidoUsuario;
        this.idRolUsuario = idRolUsuario;
        this.usuarioActivo = usuarioActivo;
    }

    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getContraseña() {
        return contraseña;
    }
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getApellidoUsuario() {
        return apellidoUsuario;
    }
    public void setApellidoUsuario(String apellidoUsuario) {
        this.apellidoUsuario = apellidoUsuario;
    }

    public int getIdRolUsuario() {
        return idRolUsuario;
    }
    public void setIdRolUsuario(int idRolUsuario) {
        this.idRolUsuario = idRolUsuario;
    }

    public String getNombreRol() {
        return nombreRol;
    }
    public void setNombreRol(String nombreRol) {
        this.nombreRol = nombreRol;
    }

    public boolean isUsuarioActivo() {
        return usuarioActivo;
    }
    public void setUsuarioActivo(boolean usuarioActivo) {
        this.usuarioActivo = usuarioActivo;
    }

}
