    package com.distribuidora;
    
    import java.util.Comparator;
    import java.util.List;
    import java.io.IOException;
    import java.time.LocalDate;
    import java.time.format.DateTimeFormatter;
    import javafx.fxml.FXML;
    import javafx.fxml.FXMLLoader;
    import javafx.collections.FXCollections;
    import javafx.collections.ObservableList;
    import javafx.collections.transformation.FilteredList;
    import javafx.collections.transformation.SortedList;
    import javafx.scene.control.*;
    import javafx.scene.Parent;
    import javafx.scene.Scene;
    import javafx.scene.control.cell.PropertyValueFactory;
    import javafx.stage.Modality;
    import javafx.stage.Stage;
    import javafx.beans.property.ReadOnlyStringWrapper;
    
    public class ProductoController {
    
        // Lista temporal
        private static final ObservableList<MovimientoStock> listaMovimientos = FXCollections.observableArrayList();
    
        private Producto productoSeleccionado;
        private final ProductoDAO productoDAO = new ProductoDAO();
    
        // fx:id de la vista principal de productos
        @FXML private TextField buscarProductoProductosField;
        @FXML private TableView<Producto> productosTable;
        @FXML private TableColumn<Producto, Integer> codigoColumn;
        @FXML private TableColumn<Producto, String> descripcionColumn;
        @FXML private TableColumn<Producto, Float> precioColumn;
        @FXML private TableColumn<Producto, Integer> stockColumn;
        @FXML private TableColumn<Producto, Object> accionesColumn;
        @FXML private Pagination paginacionProductos;
        private static final int PRODUCTOS_POR_PAGINA = 10;
        @FXML private CheckBox soloStockBajoCheckBox;
    
        // fx:id del formulario de producto
        @FXML private TextField idProductoField;
        @FXML private TextField descripcionField;
        @FXML private TextField precioField;
        @FXML private TextField stockMinimoField;
        @FXML private TextField stockMaximoField;
        @FXML private TextField stockActualField;
    
        // fx:id de la eliminación de un producto, ingreso/egreso de stock
        @FXML private Label idProductoLabel;
        @FXML private Label descripcionLabel;
        @FXML private Label stockActualLabel;
        @FXML private TextField cantidadField;
    
        // fx:id del historial
        @FXML private TextField buscarProductoField;
        @FXML private DatePicker desdeDatePicker;
        @FXML private DatePicker hastaDatePicker;
        @FXML private TableView<MovimientoStock> historialTable;
        @FXML private TableColumn<MovimientoStock, String> fechaHoraColumn;
        @FXML private TableColumn<MovimientoStock, String> productoColumn;
        @FXML private TableColumn<MovimientoStock, String> tipoColumn;
        @FXML private TableColumn<MovimientoStock, String> cantidadColumn;
        @FXML private Pagination paginacion;
        private FilteredList<MovimientoStock> movimientosFiltrados;
        private SortedList<MovimientoStock> movimientosOrdenados;
        private static final int MOVIMIENTOS_POR_PAGINA = 10;
    
    
        // Mensaje emergente
        private void mostrarMensaje(String titulo, String mensaje) {
            Alert alerta = new Alert(Alert.AlertType.INFORMATION);
            alerta.setTitle(titulo);
            alerta.setHeaderText(null);
            alerta.setContentText(mensaje);
            alerta.showAndWait();
        }
    
        // Metodo que se ejecuta al abrir/refrescar la vista (Archivo FXML)
        @FXML private void initialize() {
            if (productosTable != null) {
                productosTable.setItems(FXCollections.observableArrayList());
                productosTable.setRowFactory(tabla -> new TableRow<>() {
                    {selectedProperty().addListener((
                                observable,
                                antes,
                                ahora
                        ) -> actualizarEstilo());}
                    @Override
                    protected void updateItem(Producto producto, boolean vacio) {
                        super.updateItem(producto, vacio);
                        actualizarEstilo();
                    }
                    private void actualizarEstilo() {
                        Producto producto = getItem();
                        boolean stockBajo = !isEmpty() && producto != null
                                && producto.getStockActual() <= producto.getStockMinimo();
                        setStyle(stockBajo && !isSelected() ? "-fx-background-color: #FEE2E2;" : "");
                    }
                });
                codigoColumn.setCellValueFactory(new PropertyValueFactory<>("idProducto"));
                descripcionColumn.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
                precioColumn.setCellValueFactory(new PropertyValueFactory<>("precio"));
                stockColumn.setCellValueFactory(new PropertyValueFactory<>("stockActual"));
                configurarColumnaAcciones();
                if (paginacionProductos != null) {
                    paginacionProductos.currentPageIndexProperty().addListener(
                            (observable, anterior, nuevo) ->
                                    mostrarPaginaProductos(nuevo.intValue())
                    );
                }
                actualizarPaginacionProductos();
            }
            configurarFechasHistorial();
            configurarHistorial();
            configurarControlPaginacion();
        }
    
        // Creacion del producto que se haya seleccionado en la columna Acciones
        public void setProducto(Producto producto) {
            this.productoSeleccionado = producto;
            cargarDatosProducto();
        }
        private void cargarDatosProducto() {
            if (productoSeleccionado == null) {
                return;
            }
            if (idProductoField != null) {
                idProductoField.setText(String.valueOf(productoSeleccionado.getIdProducto()));
            }
            if (descripcionField != null) {
                descripcionField.setText(productoSeleccionado.getDescripcion());
            }
            if (precioField != null) {
                precioField.setText(String.valueOf(productoSeleccionado.getPrecio()));
            }
            if (stockMinimoField != null) {
                stockMinimoField.setText(String.valueOf(productoSeleccionado.getStockMinimo()));
            }
            if (stockMaximoField != null) {
                stockMaximoField.setText(String.valueOf(productoSeleccionado.getStockMaximo()));
            }
            if (stockActualField != null) {
                stockActualField.setText(String.valueOf(productoSeleccionado.getStockActual()));
            }
            if (descripcionLabel != null) {
                descripcionLabel.setText(productoSeleccionado.getDescripcion());
            }
            if (idProductoLabel != null) {
                idProductoLabel.setText(String.valueOf(productoSeleccionado.getIdProducto()));
            }
            if (stockActualLabel != null) {
                stockActualLabel.setText(String.valueOf(productoSeleccionado.getStockActual()));
            }
        }

        // Devuelve el mensaje de error si los valores del producto no son válidos, o null si están bien
        private String validarValoresProducto(float precio, int stockMinimo, int stockMaximo) {
            if (!Float.isFinite(precio) || precio <= 0) {
                return "El precio debe ser mayor que 0.";
            }
            if (stockMinimo < 0) {
                return "El stock mínimo no puede ser negativo.";
            }
            if (stockMaximo <= 0) {
                return "El stock máximo debe ser mayor que 0.";
            }
            if (stockMaximo < stockMinimo) {
                return "El stock máximo (" + stockMaximo + ") no puede ser menor que el stock mínimo ("
                        + stockMinimo + ").";
            }
            return null;
        }
    
        // Acciones de la vista principal
        private void abrirVistaProducto(String nombreVista, Producto producto) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(nombreVista));
                Parent vista = loader.load();
                ProductoController controlador = loader.getController();
                controlador.setProducto(producto);
                Stage ventana = new Stage();
                ventana.setTitle("Ver producto");
                ventana.setScene(new Scene(vista));
                ventana.initModality(Modality.APPLICATION_MODAL);
                ventana.setResizable(false);
                ventana.showAndWait();
                actualizarPaginacionProductos();
            } catch (IOException | NullPointerException e) {
                e.printStackTrace();
                mostrarMensaje("Error", "No se pudo abrir la vista del producto.");
            }
        }
        @FXML private void volverAlInicio() {
            try {
                Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/menu-view.fxml"));
                Stage ventana = (Stage) productosTable.getScene().getWindow();
                ventana.setScene(new Scene(vista));
                ventana.setMaximized(true);
            } catch (IOException e) {
                e.printStackTrace();
                mostrarMensaje("Error", "No se pudo volver a la pantalla principal.");
            }
        }
        @FXML private void nuevoProducto() {
            abrirVistaProducto("/resources/com/distribuidora/registrar-producto-view.fxml", null);
        }
        @FXML private void registrarProducto() {
            if (descripcionField == null || precioField == null
                    || stockMinimoField == null || stockMaximoField == null) {
                return;
            }
            try {
                String descripcion = descripcionField.getText().trim();
                String precioTexto = precioField.getText().trim();
                String minimoTexto = stockMinimoField.getText().trim();
                String maximoTexto = stockMaximoField.getText().trim();
                if (descripcion.isEmpty() || precioTexto.isEmpty()
                        || minimoTexto.isEmpty() || maximoTexto.isEmpty()) {
                    mostrarMensaje("Campos incompletos", "Completá todos los campos.");
                    return;
                }
                if (descripcion.length() < 2 || descripcion.length() > 254) {
                    mostrarMensaje("Validación",
                            "La descripcion debe tener 2 caracteres como mínimo y 254 como máximo");
                    return;
                }
                float precio = Float.parseFloat(precioTexto.replace(',', '.'));
                int minimo = Integer.parseInt(minimoTexto);
                int maximo = Integer.parseInt(maximoTexto);
                String error = validarValoresProducto(precio, minimo, maximo);
                if (error != null) {
                    mostrarMensaje("Datos inválidos", error);
                    return;
                }
                // El ID será generado por MySQL.
                Producto producto = new Producto(
                        0,
                        descripcion,
                        precio,
                        minimo,
                        maximo,
                        0
                );
                int filasAfectadas = productoDAO.insertar(producto);
                if (filasAfectadas == 0) {
                    mostrarMensaje("Error", "No se pudo registrar el producto.");
                    return;
                }
                actualizarPaginacionProductos();
                mostrarMensaje("Producto registrado",
                        "El producto " + producto.getDescripcion() + " se registró correctamente."
                );
                cerrarVentana();
            } catch (NumberFormatException e) {
                mostrarMensaje("Datos inválidos",
                        "Revisá el precio y los valores de stock. Deben ser números válidos."
                );
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error de base de datos",
                        "No se pudo registrar el producto. Verificá la conexión e intentá nuevamente."
                );
            }
        }
        @FXML private void eliminarProducto() {
            if (productoSeleccionado == null) {
                mostrarMensaje("Error", "No se seleccionó ningún producto.");
                return;
            }
            try {
                int filasAfectadas = productoDAO.eliminar(productoSeleccionado.getIdProducto());
                if (filasAfectadas == 0) {
                    mostrarMensaje("Información",
                            "El producto seleccionado no existe."
                    );
                    return;
                }
                actualizarPaginacionProductos();
                mostrarMensaje("Éxito", "Producto eliminado correctamente.");
                cerrarVentana();
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error de base de datos",
                        "No se pudo eliminar el producto. Puede estar asociado a ventas, pedidos u otros registros."
                );
            }
        }
        @FXML private void modificarProducto() {
            if (productoSeleccionado == null) {
                mostrarMensaje("Error", "No se seleccionó ningún producto.");
                return;
            }
    
            try {
                String descripcion = descripcionField.getText().trim();
                float precio = Float.parseFloat(
                        precioField.getText().trim().replace(',', '.'));
                int stockMinimo = Integer.parseInt(
                        stockMinimoField.getText().trim());
                int stockMaximo = Integer.parseInt(
                        stockMaximoField.getText().trim());
    
                if (descripcion.isEmpty()) {
                    mostrarMensaje("Error", "La descripción es obligatoria.");
                    return;
                }
                String error = validarValoresProducto(precio, stockMinimo, stockMaximo);
                if (error != null) {
                    mostrarMensaje("Error", error);
                    return;
                }
                Producto productoActualizado = new Producto();
                productoActualizado.setIdProducto(productoSeleccionado.getIdProducto());
                productoActualizado.setDescripcion(descripcion);
                productoActualizado.setPrecio(precio);
                productoActualizado.setStockMinimo(stockMinimo);
                productoActualizado.setStockMaximo(stockMaximo);
                try {
                    int filasAfectadas = productoDAO.actualizar(productoActualizado);
                    if (filasAfectadas == 0) {
                        mostrarMensaje("Información",
                                "No se modificaron filas. Verificá que los datos hayan cambiado."
                        );
                        return;
                    }
                    actualizarPaginacionProductos();
                } catch (java.sql.SQLException e) {
                    mostrarMensaje("Error", "No se pudo actualizar el producto.");
                    throw e;
                }
                mostrarMensaje("Éxito", "Producto actualizado correctamente.");
                cerrarVentana();
            } catch (NumberFormatException e) {
                mostrarMensaje("Error",
                        "El precio y los stocks deben tener valores numéricos válidos."
                );
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error de base de datos",
                        "No se pudieron guardar los cambios del producto."
                );
            }
        }
        @FXML private void ingresarStock() {
            if (productoSeleccionado == null) {
                mostrarMensaje("Error", "No se seleccionó ningún producto.");
                return;
            }
            try {
                int cantidad = Integer.parseInt(cantidadField.getText().trim());
                if (cantidad <= 0) {
                    mostrarMensaje("Error","La cantidad debe ser mayor que cero.");
                    return;
                }
                if (productoDAO.registrarIngresoStock(productoSeleccionado.getIdProducto(),cantidad) != 0) {
                    productoSeleccionado.setStockActual(productoSeleccionado.getStockActual() + cantidad);
                    listaMovimientos.add(new MovimientoStock(productoSeleccionado, "Ingreso", cantidad));
                    mostrarMensaje("Éxito", "Se ingresaron " + cantidad
                            + " unidades de " + productoSeleccionado.getDescripcion() + "."
                    );
                    cerrarVentana();
                } else {
                    mostrarMensaje("Error", "No se encontro el producto para actualizar.");
                }
            } catch (NumberFormatException e) {
                mostrarMensaje("Error",
                        "Ingresá una cantidad entera válida."
                );
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error de base de datos",
                        "No se pudo registrar el ingreso de stock."
                );
            }
        }
        @FXML private void egresarStock() {
            if (productoSeleccionado == null) {
                mostrarMensaje("Error", "No se seleccionó ningún producto.");
                return;
            }
            try {
                int cantidad = Integer.parseInt(
                        cantidadField.getText().trim()
                );
                if (cantidad <= 0) {
                    mostrarMensaje("Error", "La cantidad debe ser mayor que cero.");
                    return;
                }
                if (cantidad > productoSeleccionado.getStockActual()) {
                    mostrarMensaje("Error", "No hay suficiente stock para realizar el egreso.");
                    return;
                }
                if (productoDAO.registrarEgresoStock(productoSeleccionado.getIdProducto(), cantidad) != 0) {
                    productoSeleccionado.setStockActual(productoSeleccionado.getStockActual() - cantidad);
                    listaMovimientos.add(new MovimientoStock(productoSeleccionado, "Egreso", cantidad));
                    mostrarMensaje("Éxito", "Se egresaron " + cantidad
                            + " unidades de " + productoSeleccionado.getDescripcion() + "."
                    );
                } else {
                    mostrarMensaje("Error", "No se encontro el producto para actualizar.");
                }
                cerrarVentana();
            } catch (NumberFormatException e) {
                mostrarMensaje("Error","Ingresá una cantidad entera válida.");
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error de base de datos",
                        "No se pudo registrar el egreso. Verificá el stock disponible e intentá nuevamente."
                );
            }
        }
        @FXML private void consultarHistorialStock() {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/com/distribuidora/historial-stock-view.fxml"));
                Parent vista = loader.load();
    
                Stage ventana = new Stage();
                ventana.setTitle("Historial de movimientos de stock");
                ventana.setScene(new Scene(vista));
                ventana.initModality(Modality.APPLICATION_MODAL);
                ventana.setResizable(false);
                ventana.showAndWait();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    
        private void cerrarVentana() {
            if (descripcionLabel != null && descripcionLabel.getScene() != null) {
                Stage ventana = (Stage) descripcionLabel.getScene().getWindow();
                ventana.close();
            } else if (descripcionField != null && descripcionField.getScene() != null) {
                Stage ventana = (Stage) descripcionField.getScene().getWindow();
                ventana.close();
            }
        }
        @FXML private void cancelar() {
            if (historialTable != null && historialTable.getScene() != null) {
                Stage ventana = (Stage) historialTable.getScene().getWindow();
                ventana.close();
            } else {
                cerrarVentana();
            }
        }
    
        private void configurarColumnaAcciones() {
            accionesColumn.setCellFactory(columna -> new TableCell<>() {
                private final Button accionesButton = new Button("⋮"); {
                    accionesButton.setOnAction(event -> {
                        Producto producto = getTableView().getItems().get(getIndex());
                        ContextMenu menu = new ContextMenu();
    
                        MenuItem verItem = new MenuItem("Ver");
                        MenuItem editarItem = new MenuItem("Editar");
                        MenuItem eliminarItem = new MenuItem("Eliminar");
                        MenuItem ingresarStockItem = new MenuItem("Ingresar stock");
                        MenuItem egresarStockItem = new MenuItem("Egresar stock");
    
                        verItem.setOnAction(e ->
                                abrirVistaProducto("/resources/com/distribuidora/ver-producto-view.fxml", producto)
                        );
    
                        editarItem.setOnAction(e ->
                                abrirVistaProducto("/resources/com/distribuidora/editar-producto-view.fxml", producto));
    
                        eliminarItem.setOnAction(e ->
                                abrirVistaProducto("/resources/com/distribuidora/eliminar-producto-view.fxml", producto));
    
                        ingresarStockItem.setOnAction(e ->
                                abrirVistaProducto("/resources/com/distribuidora/ingresar-stock-view.fxml", producto));
    
                        egresarStockItem.setOnAction(e ->
                                abrirVistaProducto("/resources/com/distribuidora/egresar-stock-view.fxml", producto));
    
                        menu.getItems().addAll(verItem, editarItem, eliminarItem, ingresarStockItem, egresarStockItem);
                        menu.show(accionesButton, javafx.geometry.Side.BOTTOM, 0, 0);
                    });
                }
                @Override
                protected void updateItem(Object item, boolean empty) {
                    super.updateItem(item, empty);
                    setGraphic(empty ? null : accionesButton);
                }
            });
        }
    
        private void configurarHistorial() {
            if (historialTable == null || paginacion == null) {
                return;
            }
            DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    
            fechaHoraColumn.setCellValueFactory(dato ->
                    new ReadOnlyStringWrapper(dato.getValue().getFechaHora().format(formatoFecha))
            );
            productoColumn.setCellValueFactory(dato ->
                    new ReadOnlyStringWrapper(dato.getValue().getProducto().getDescripcion())
            );
            tipoColumn.setCellValueFactory(dato ->
                    new ReadOnlyStringWrapper(dato.getValue().getTipo())
            );
            cantidadColumn.setCellValueFactory(dato ->
                    new ReadOnlyStringWrapper(String.valueOf(dato.getValue().getCantidadConSigno()))
            );
    
            try {
                listaMovimientos.setAll(productoDAO.listarHistorial());
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error de base de datos",
                        "No se pudo cargar el historial desde MySQL."
                );
            }
            movimientosFiltrados = new FilteredList<>(listaMovimientos, movimiento -> true);
            movimientosOrdenados = new SortedList<>(movimientosFiltrados);
            movimientosOrdenados.setComparator(Comparator.comparing(MovimientoStock::getFechaHora).reversed());
            actualizarPaginacionHistorial();
        }
        private void configurarFechasHistorial() {
            if (desdeDatePicker != null) {
                desdeDatePicker.setEditable(false);
                desdeDatePicker.setDayCellFactory(picker -> new DateCell() {
                    @Override
                    public void updateItem(LocalDate fecha, boolean vacio) {
                        super.updateItem(fecha, vacio);
                        if (vacio || fecha == null) {
                            setDisable(true);
                            return;
                        }
                        LocalDate hasta = hastaDatePicker == null ? null : hastaDatePicker.getValue();
                        setDisable(fecha.isAfter(LocalDate.now()) || (hasta != null && fecha.isAfter(hasta)));
                    }
                });
            }
            if (hastaDatePicker != null) {
                hastaDatePicker.setEditable(false);
                hastaDatePicker.setDayCellFactory(picker -> new DateCell() {
                    @Override
                    public void updateItem(LocalDate fecha, boolean vacio) {
                        super.updateItem(fecha, vacio);
                        if (vacio || fecha == null) {
                            setDisable(true);
                            return;
                        }
                        LocalDate desde = desdeDatePicker == null ? null : desdeDatePicker.getValue();
                        setDisable(fecha.isAfter(LocalDate.now()) || (desde != null && fecha.isBefore(desde)));
                    }
                });
            }
        }
        private void actualizarPaginacionHistorial() {
            if (historialTable == null || paginacion == null
                    || movimientosFiltrados == null) {
                return;
            }
            int total = movimientosFiltrados.size();
            int cantidadPaginas = Math.max(1,(int) Math.ceil((double) total / MOVIMIENTOS_POR_PAGINA));
            paginacion.setPageCount(cantidadPaginas);
            int paginaActual = Math.min(paginacion.getCurrentPageIndex(),cantidadPaginas - 1);
            paginacion.setCurrentPageIndex(paginaActual);
            mostrarPaginaHistorial(paginaActual);
        }
        private void mostrarPaginaHistorial(int indicePagina) {
            if (historialTable == null || movimientosOrdenados == null) {
                return;
            }
            int inicio = indicePagina * MOVIMIENTOS_POR_PAGINA;
            int fin = Math.min(inicio + MOVIMIENTOS_POR_PAGINA,movimientosOrdenados.size());
            historialTable.getItems().setAll(movimientosOrdenados.subList(inicio, fin));
        }
    
        private void configurarControlPaginacion() {
            if (paginacion != null) {
                paginacion.currentPageIndexProperty().addListener(
                        (observable, anterior, nueva) ->
                                mostrarPaginaHistorial(nueva.intValue())
                );
            }
        }
        private boolean soloStockBajo() {
            return soloStockBajoCheckBox != null && soloStockBajoCheckBox.isSelected();
        }
        private void actualizarPaginacionProductos() {
            if (productosTable == null || paginacionProductos == null) {
                return;
            }
            try {
                String filtro = buscarProductoProductosField == null
                        ? "" : buscarProductoProductosField.getText().trim();
                int cantidadProductos = productoDAO.contarProductos(filtro, soloStockBajo());
                int cantidadPaginas = (int) Math.ceil((double) cantidadProductos / PRODUCTOS_POR_PAGINA);
                cantidadPaginas = Math.max(1,cantidadPaginas);
                paginacionProductos.setPageCount(cantidadPaginas);
                int paginaActual = Math.min(paginacionProductos.getCurrentPageIndex(), cantidadPaginas - 1);
                if (paginacionProductos.getCurrentPageIndex() != paginaActual) {
                    paginacionProductos.setCurrentPageIndex(paginaActual);
                } else {
                    mostrarPaginaProductos(paginaActual);
                }
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error de base de datos",
                        "No se pudo calcular la cantidad de productos."
                );
            }
        }
        private void mostrarPaginaProductos(int indicePagina) {
            if (productosTable == null) {
                return;
            }
            try {
                String filtro = buscarProductoProductosField == null
                        ? "" : buscarProductoProductosField.getText().trim();
                int offset = indicePagina * PRODUCTOS_POR_PAGINA;
                List<Producto> productos = productoDAO.listarPaginaProducto(
                        PRODUCTOS_POR_PAGINA,
                        offset,
                        filtro,
                        soloStockBajo()
                );
                productosTable.getItems().setAll(productos);
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error de base de datos",
                        "No se pudieron cargar los productos de esta página."
                );
            }
        }

        // Activa el filtro "Solo stock bajo" (se usa al llegar desde la alerta del menú)
        public void activarSoloStockBajo() {
            if (soloStockBajoCheckBox == null) {
                return;
            }
            soloStockBajoCheckBox.setSelected(true);
            filtrarProductos();
        }

        @FXML private void filtrarProductos() {
            if (buscarProductoProductosField == null) {
                return;
            }
            if (paginacionProductos != null) {
                paginacionProductos.setCurrentPageIndex(0);
            }
            actualizarPaginacionProductos();
        }
        @FXML private void filtrarMovimientos() {
            if (movimientosFiltrados == null) {
                return;
            }
            String nombre = buscarProductoField == null
                    || buscarProductoField.getText() == null ? "" : buscarProductoField.getText().trim().toLowerCase();
            LocalDate desde = desdeDatePicker == null ? null : desdeDatePicker.getValue();
            LocalDate hasta = hastaDatePicker == null ? null : hastaDatePicker.getValue();
    
            movimientosFiltrados.setPredicate(movimiento -> {
                String descripcion = movimiento.getProducto().getDescripcion();
                boolean coincideNombre = nombre.isEmpty() || (descripcion != null
                        && descripcion.toLowerCase().contains(nombre));
                LocalDate fechaMovimiento = movimiento.getFechaHora().toLocalDate();
                boolean coincideDesde = desde == null || !fechaMovimiento.isBefore(desde);
                boolean coincideHasta = hasta == null || !fechaMovimiento.isAfter(hasta);
                return coincideNombre && coincideDesde && coincideHasta;
            });
            paginacion.setCurrentPageIndex(0);
            actualizarPaginacionHistorial();
        }
        @FXML private void limpiarFiltrosMovimientos() {
            if (buscarProductoField != null) {
                buscarProductoField.clear();
            }
            if (desdeDatePicker != null) {
                desdeDatePicker.setValue(null);
            }
            if (hastaDatePicker != null) {
                hastaDatePicker.setValue(null);
            }
            filtrarMovimientos();
        }
    }