package com.distribuidora;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    // Registrar un producto nuevo
    public int insertar(Producto producto) throws SQLException {
        String sql = """
        INSERT INTO producto
            (descripcion, precio, stockMinimo,
             stockMaximo, stockActual)
        VALUES (?, ?, ?, ?, ?)
        """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS)) {
            sentencia.setString(1, producto.getDescripcion());
            sentencia.setFloat(2, producto.getPrecio());
            sentencia.setInt(3, producto.getStockMinimo());
            sentencia.setInt(4, producto.getStockMaximo());
            sentencia.setInt(5, producto.getStockActual());
            int filas = sentencia.executeUpdate();
            try (ResultSet claves = sentencia.getGeneratedKeys()) {
                if (claves.next()) {
                    producto.setIdProducto(claves.getInt(1));
                }
            }
            return filas;
        }
    }

    //Elimina un producto existente
    public int eliminar(int idProducto) throws SQLException {
        String sql = "DELETE FROM producto WHERE idProducto = ?";
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idProducto);
            return sentencia.executeUpdate();
        }
    }

    //Actualiza un producto existente
    public int actualizar(Producto producto) throws SQLException {
        String sql = """
            UPDATE producto
            SET descripcion = ?,
                precio = ?,
                stockMinimo = ?,
                stockMaximo = ?
            WHERE idProducto = ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, producto.getDescripcion());
            sentencia.setFloat(2, producto.getPrecio());
            sentencia.setInt(3, producto.getStockMinimo());
            sentencia.setInt(4, producto.getStockMaximo());
            sentencia.setInt(5, producto.getIdProducto());

            return sentencia.executeUpdate();
        }
    }

    // Suma stock a un producto y guarda el movimiento en el historial
    public int registrarIngresoStock(int idProducto, int cantidad)
            throws SQLException {
        String sqlActualizar = """
            UPDATE producto
            SET stockActual = stockActual + ?
            WHERE idProducto = ?
            """;
        String sqlHistorial = """
            INSERT INTO historial
                (fecha, idProducto, cantidad, tipoMovimiento)
            VALUES (CURRENT_TIMESTAMP, ?, ?, ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar()) {
            conexion.setAutoCommit(false);
            try {
                int filas;
                try (PreparedStatement sentencia = conexion.prepareStatement(sqlActualizar)) {
                    sentencia.setInt(1, cantidad);
                    sentencia.setInt(2, idProducto);
                    filas = sentencia.executeUpdate();
                }
                if (filas!=0) {
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlHistorial)) {
                        sentencia.setInt(1, idProducto);
                        sentencia.setInt(2, cantidad);
                        sentencia.setString(3, "Ingreso");
                        sentencia.executeUpdate();
                    }
                }
                conexion.commit();
                return filas;
            } catch (SQLException e) {
                conexion.rollback();
                throw e;
            } finally {
                conexion.setAutoCommit(true);
            }
        }
    }

    // Resta stock a un producto y guarda el movimiento en el historial
    public int registrarEgresoStock(int idProducto, int cantidad)
            throws SQLException {
        String sqlActualizar = """
            UPDATE producto
            SET stockActual = stockActual - ?
            WHERE idProducto = ?
              AND stockActual >= ?
            """;
        String sqlHistorial = """
            INSERT INTO historial
                (fecha, idProducto, cantidad, tipoMovimiento)
            VALUES (CURRENT_TIMESTAMP, ?, ?, ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar()) {
            conexion.setAutoCommit(false);
            try {
                int filas;
                try (PreparedStatement sentencia = conexion.prepareStatement(sqlActualizar)) {
                    sentencia.setInt(1, cantidad);
                    sentencia.setInt(2, idProducto);
                    sentencia.setInt(3, cantidad);
                    filas = sentencia.executeUpdate();
                }
                if (filas != 0) {
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlHistorial)) {
                        sentencia.setInt(1, idProducto);
                        sentencia.setInt(2, cantidad);
                        sentencia.setString(3, "Egreso");
                        sentencia.executeUpdate();
                    }
                }
                conexion.commit();
                return filas;
            } catch (SQLException e) {
                conexion.rollback();
                throw e;
            } finally {
                conexion.setAutoCommit(true);
            }
        }
    }

    // Pide a la base de datos los productos para la paginación de las tablas, respetando filtros
    public List<Producto> listarPaginaProducto(
            int limite, int offset, String filtro) throws SQLException {
        return listarPaginaProducto(limite, offset, filtro, false);
    }

    public List<Producto> listarPaginaProducto(
            int limite, int offset, String filtro, boolean soloStockBajo) throws SQLException {
        List<Producto> productos = new ArrayList<>();
        String condicionStock = soloStockBajo ? " AND stockActual <= stockMinimo\n" : "";
        String sql = """
        SELECT idProducto, descripcion, precio,
               stockMinimo, stockMaximo, stockActual
        FROM producto
        WHERE (? = ''
               OR descripcion LIKE ?
               OR CAST(idProducto AS CHAR) LIKE ?)
        """ + condicionStock + """
        ORDER BY idProducto
        LIMIT ? OFFSET ?
        """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            sentencia.setString(1, busqueda);
            sentencia.setString(2, "%" + busqueda + "%");
            sentencia.setString(3, "%" + busqueda + "%");
            sentencia.setInt(4, limite);
            sentencia.setInt(5, offset);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    Producto producto = new Producto();
                    producto.setIdProducto(resultado.getInt("idProducto"));
                    producto.setDescripcion(resultado.getString("descripcion"));
                    producto.setPrecio(resultado.getFloat("precio"));
                    producto.setStockMinimo(resultado.getInt("stockMinimo"));
                    producto.setStockMaximo(resultado.getInt("stockMaximo"));
                    producto.setStockActual(resultado.getInt("stockActual"));
                    productos.add(producto);
                }
            }
        }
        return productos;
    }

    // Calcula cuantos productos hay para determinar la cantidad de páginas
    public int contarProductos(String filtro) throws SQLException {
        return contarProductos(filtro, false);
    }

    public int contarProductos(String filtro, boolean soloStockBajo) throws SQLException {
        String condicionStock = soloStockBajo ? " AND stockActual <= stockMinimo" : "";
        String sql = """
        SELECT COUNT(*)
        FROM producto
        WHERE (? = ''
               OR descripcion LIKE ?
               OR CAST(idProducto AS CHAR) LIKE ?)
        """ + condicionStock;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            sentencia.setString(1, busqueda);
            sentencia.setString(2, "%" + busqueda + "%");
            sentencia.setString(3, "%" + busqueda + "%");
            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {
                    return resultado.getInt(1);
                }
            }
        }
        return 0;
    }

    // Cuenta los productos que llegaron al stock mínimo o están por debajo
    public int contarStockBajo() throws SQLException {
        String sql = "SELECT COUNT(*) FROM producto WHERE stockActual <= stockMinimo";
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {
            resultado.next();
            return resultado.getInt(1);
        }
    }

    // Recupera los movimientos guardados
    public List<MovimientoStock> listarHistorial() throws SQLException {
        List<MovimientoStock> movimientos = new ArrayList<>();
        String sql = """
            SELECT h.fecha, h.idProducto, h.cantidad,
                   h.tipoMovimiento, p.descripcion
            FROM historial h
            INNER JOIN producto p
                ON h.idProducto = p.idProducto
            ORDER BY h.fecha DESC
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {
            while (resultado.next()) {
                Producto producto = new Producto();
                producto.setIdProducto(resultado.getInt("idProducto"));
                producto.setDescripcion(resultado.getString("descripcion"));
                java.sql.Timestamp timestamp = resultado.getTimestamp("fecha");
                LocalDateTime fechaHora = timestamp.toLocalDateTime();
                MovimientoStock movimiento = new MovimientoStock(
                        producto,
                        resultado.getString("tipoMovimiento"),
                        resultado.getInt("cantidad"),
                        fechaHora
                );
                movimientos.add(movimiento);
            }
        }
        return movimientos;
    }

    // Productos que llegaron al stock mínimo o están por debajo, los más urgentes primero
    public List<Producto> listarStockBajo(int limite) throws SQLException {
        List<Producto> productos = new ArrayList<>();
        String sql = """
        SELECT idProducto, descripcion, stockMinimo, stockActual
        FROM producto
        WHERE stockActual <= stockMinimo
        ORDER BY (stockActual - stockMinimo), idProducto
        LIMIT ?
        """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, limite);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    Producto producto = new Producto();
                    producto.setIdProducto(resultado.getInt("idProducto"));
                    producto.setDescripcion(resultado.getString("descripcion"));
                    producto.setStockMinimo(resultado.getInt("stockMinimo"));
                    producto.setStockActual(resultado.getInt("stockActual"));
                    productos.add(producto);
                }
            }
        }
        return productos;
    }
}
