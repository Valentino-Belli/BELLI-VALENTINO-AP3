package com.distribuidora;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    // Buscar cliente por DNI
    public Cliente buscarPorDni(String dni) throws SQLException {
        String sql = """
            SELECT idCliente, nombreCliente, apellidoCliente,
                   dni, telefono, email, direccion
            FROM cliente
            WHERE dni = ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, dni);
            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {
                    return mapearCliente(resultado);
                }
                return null;
            }
        }
    }
    // Buscar cliente por email
    public Cliente buscarPorEmail(String email) throws SQLException {
        String sql = """
            SELECT idCliente, nombreCliente, apellidoCliente,
                   dni, telefono, email, direccion
            FROM cliente
            WHERE email = ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, email);
            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {
                    return mapearCliente(resultado);
                }
                return null;
            }
        }
    }

    // Convierte una fila de la base de datos en un objeto Cliente
    private Cliente mapearCliente(ResultSet resultado) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setIdCliente(resultado.getInt("idCliente"));
        cliente.setNombreCliente(resultado.getString("nombreCliente"));
        cliente.setApellidoCliente(resultado.getString("apellidoCliente"));
        cliente.setDni(resultado.getString("dni"));
        cliente.setTelefono(resultado.getString("telefono"));
        cliente.setEmail(resultado.getString("email"));
        cliente.setDireccion(resultado.getString("direccion"));
        return cliente;
    }

    // Registrar un cliente nuevo
    public int insertar(Cliente cliente) throws SQLException {
        String sql = """
            INSERT INTO cliente (
                nombreCliente,
                apellidoCliente,
                dni,
                telefono,
                email,
                direccion
            ) VALUES (?, ?, ?, ?, ?, ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, cliente.getNombreCliente());
            sentencia.setString(2, cliente.getApellidoCliente());
            sentencia.setString(3, cliente.getDni());
            sentencia.setString(4, cliente.getTelefono());
            sentencia.setString(5, cliente.getEmail());
            sentencia.setString(6, cliente.getDireccion());
            return sentencia.executeUpdate();
        }
    }

    // Eliminar un cliente
    public int eliminar(int idCliente) throws SQLException {
        String sql = "DELETE FROM cliente WHERE idCliente = ?";
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idCliente);
            return sentencia.executeUpdate();
        }
    }

    // Actualizar un cliente
    public int actualizar(Cliente cliente) throws SQLException {
        String sql = """
            UPDATE cliente
            SET nombreCliente = ?,
                apellidoCliente = ?,
                dni = ?,
                telefono = ?,
                email = ?,
                direccion = ?
            WHERE idCliente = ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, cliente.getNombreCliente());
            sentencia.setString(2, cliente.getApellidoCliente());
            sentencia.setString(3, cliente.getDni());
            sentencia.setString(4, cliente.getTelefono());
            sentencia.setString(5, cliente.getEmail());
            sentencia.setString(6, cliente.getDireccion());
            sentencia.setInt(7, cliente.getIdCliente());
            return sentencia.executeUpdate();
        }
    }

    // Listar clientes por página y aplicar filtro
    public List<Cliente> listarPagina(
            int limite, int offset, String filtro) throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        String sql = """
            SELECT idCliente, nombreCliente, apellidoCliente,
                   dni, telefono, email, direccion
            FROM cliente
            WHERE (? = ''
                   OR CAST(idCliente AS CHAR) LIKE ?
                   OR nombreCliente LIKE ?
                   OR apellidoCliente LIKE ?
                   OR dni LIKE ?)
            ORDER BY idCliente
            LIMIT ? OFFSET ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            for (int i = 2; i <= 5; i++) {
                sentencia.setString(i, patron);
            }
            sentencia.setInt(6, limite);
            sentencia.setInt(7, offset);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    clientes.add(mapearCliente(resultado));
                }
            }
        }
        return clientes;
    }

    // Contar clientes que coinciden con el filtro
    public int contarClientes(String filtro) throws SQLException {
        String sql = """
            SELECT COUNT(*)
            FROM cliente
            WHERE (? = ''
                   OR CAST(idCliente AS CHAR) LIKE ?
                   OR nombreCliente LIKE ?
                   OR apellidoCliente LIKE ?
                   OR dni LIKE ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            for (int i = 2; i <= 5; i++) {
                sentencia.setString(i, patron);
            }
            try (ResultSet resultado = sentencia.executeQuery()) {
                resultado.next();
                return resultado.getInt(1);
            }
        }
    }

    // Busca clientes por DNI, nombre, apellido o nombre completo (para los ComboBox)
    public List<Cliente> buscarPorDniONombre(String filtro, int limite) throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        String sql = """
        SELECT idCliente, nombreCliente, apellidoCliente,
               dni, telefono, email, direccion
        FROM cliente
        WHERE (? = ''
               OR dni LIKE ?
               OR nombreCliente LIKE ?
               OR apellidoCliente LIKE ?
               OR CONCAT(nombreCliente, ' ', apellidoCliente) LIKE ?)
        ORDER BY apellidoCliente, nombreCliente
        LIMIT ?
        """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            for (int i = 2; i <= 5; i++) {
                sentencia.setString(i, patron);
            }
            sentencia.setInt(6, limite);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    clientes.add(mapearCliente(resultado));
                }
            }
        }
        return clientes;
    }
}
