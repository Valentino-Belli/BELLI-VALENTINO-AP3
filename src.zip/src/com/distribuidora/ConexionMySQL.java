package com.distribuidora;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionMySQL {

    private static final String URL = "jdbc:mysql://localhost:3306/gestion_stock_distribuidora";
    private static final String USUARIO = "root";
    private static final String CONTRASENA = "----";

    public static Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("No se encontró el driver de MySQL: " + e.getMessage());
        }
        return DriverManager.getConnection(URL, USUARIO, CONTRASENA);
    }
}

