package com.distribuidora;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class PedidoController {

    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final ProveedorDAO proveedorDAO = new ProveedorDAO();
    private final ProductoDAO productoDAO = new ProductoDAO();
    private Pedido pedidoSeleccionado;

    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    // Máximo que entra en un DECIMAL(10,2)
    private static final BigDecimal IMPORTE_MAXIMO = new BigDecimal("99999999.99");
    // Cantidad máxima de resultados que se cargan en los ComboBox en cada búsqueda
    private static final int LIMITE_COMBOBOX = 100;

    // fx:id de la vista principal de pedidos
    @FXML private TextField buscarPedidoPedidosField;
    @FXML private TableView<Pedido> pedidosTable;
    @FXML private TableColumn<Pedido, Integer> codigoColumn;
    @FXML private TableColumn<Pedido, String> fechaColumn;
    @FXML private TableColumn<Pedido, String> proveedorColumn;
    @FXML private TableColumn<Pedido, Object> accionesColumn;
    @FXML private Pagination paginacionPedidos;
    private static final int PEDIDOS_POR_PAGINA = 10;

    // fx:id de las vistas del pedido (registrar y ver)
    @FXML private Label idPedidoLabel;
    @FXML private Label fechaPedidoLabel;
    @FXML private Label proveedorPedidoLabel;
    @FXML private Label totalLabel;
    @FXML private TextField buscarProveedorField;
    @FXML private ComboBox<Proveedor> proveedorComboBox;
    @FXML private TextField buscarProductoField;
    @FXML private ComboBox<Producto> productoComboBox;
    @FXML private TextField cantidadField;
    @FXML private TextField precioUnitarioField;
    @FXML private TableView<DetallePedido> detalleTable;
    @FXML private TableColumn<DetallePedido, String> detalleProductoColumn;
    @FXML private TableColumn<DetallePedido, Integer> detalleCantidadColumn;
    @FXML private TableColumn<DetallePedido, BigDecimal> detallePrecioUnitarioColumn;
    @FXML private TableColumn<DetallePedido, BigDecimal> detalleSubtotalColumn;


    // Mensaje emergente
    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    // Da formato a un importe para mostrarlo en pantalla
    private String formatearImporte(BigDecimal importe) {
        return "$ " + importe.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    // Metodo que se ejecuta al abrir/refrescar la vista (Archivo FXML)
    @FXML private void initialize() {
        if (pedidosTable != null) {
            pedidosTable.setItems(FXCollections.observableArrayList());
            codigoColumn.setCellValueFactory(new PropertyValueFactory<>("idPedido"));
            fechaColumn.setCellValueFactory(celda ->
                    new ReadOnlyStringWrapper(celda.getValue().getFecha().format(FORMATO_FECHA)));
            proveedorColumn.setCellValueFactory(new PropertyValueFactory<>("nombreProveedor"));
            configurarColumnaAcciones();
            if (paginacionPedidos != null) {
                paginacionPedidos.currentPageIndexProperty().addListener(
                        (observable, anterior, nuevo) ->
                                mostrarPaginaPedidos(nuevo.intValue())
                );
            }
        }
        if (detalleTable != null) {
            configurarTablaDetalle();
        }
        if (proveedorComboBox != null) {
            configurarComboBoxProveedor();
            cargarProveedores("");
        }
        if (productoComboBox != null) {
            configurarComboBoxProducto();
            cargarProductos("");
        }
        if (fechaPedidoLabel != null) {
            fechaPedidoLabel.setText(LocalDate.now().format(FORMATO_FECHA));
        }
        actualizarPaginacionPedidos();
    }

    private void configurarTablaDetalle() {
        detalleTable.setItems(FXCollections.observableArrayList());
        detalleProductoColumn.setCellValueFactory(new PropertyValueFactory<>("descripcionProducto"));
        detalleCantidadColumn.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        detallePrecioUnitarioColumn.setCellValueFactory(new PropertyValueFactory<>("precioUnitario"));
        detalleSubtotalColumn.setCellValueFactory(new PropertyValueFactory<>("precioTotal"));
    }
    private void configurarComboBoxProveedor() {
        proveedorComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(Proveedor proveedor) {
                return proveedor == null ? "" : proveedor.getIdProveedor() + " - "
                        + proveedor.getNombreProveedor();
            }
            @Override
            public Proveedor fromString(String texto) {
                return null;
            }
        });
    }
    private void configurarComboBoxProducto() {
        productoComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(Producto producto) {
                return producto == null ? "" : producto.getIdProducto() + " - "
                        + producto.getDescripcion() + " (stock: " + producto.getStockActual() + ")";
            }
            @Override
            public Producto fromString(String texto) {
                return null;
            }
        });
    }
    // Rearma el ComboBox con los proveedores que coinciden con el filtro (código o nombre)
    private void cargarProveedores(String filtro) {
        try {
            List<Proveedor> proveedores = proveedorDAO.listarPagina(LIMITE_COMBOBOX, 0, filtro);
            proveedorComboBox.setValue(null);
            proveedorComboBox.setItems(FXCollections.observableArrayList(proveedores));
            if (proveedores.isEmpty() && !filtro.isBlank()) {
                mostrarMensaje("Información", "No se encontraron proveedores con ese criterio.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron cargar los proveedores.");
        }
    }
    // Rearma el ComboBox con los productos que coinciden con el filtro (código o descripción)
    private void cargarProductos(String filtro) {
        try {
            List<Producto> productos = productoDAO.listarPaginaProducto(LIMITE_COMBOBOX, 0, filtro);
            productoComboBox.setValue(null);
            productoComboBox.setItems(FXCollections.observableArrayList(productos));
            if (productos.isEmpty() && !filtro.isBlank()) {
                mostrarMensaje("Información", "No se encontraron productos con ese criterio.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron cargar los productos.");
        }
    }
    @FXML private void buscarProveedores() {
        cargarProveedores(buscarProveedorField.getText().trim());
        if (!proveedorComboBox.getItems().isEmpty()) {
            proveedorComboBox.show();
        }
    }
    @FXML private void buscarProductos() {
        cargarProductos(buscarProductoField.getText().trim());
        if (!productoComboBox.getItems().isEmpty()) {
            productoComboBox.show();
        }
    }

    // Creacion del pedido que se haya seleccionado en la columna Acciones
    public void setPedidoSeleccionado(Pedido pedido) {
        this.pedidoSeleccionado = pedido;
        cargarDatosPedido();
    }
    private void cargarDatosPedido() {
        if (pedidoSeleccionado == null) {
            return;
        }
        if (idPedidoLabel != null) {
            idPedidoLabel.setText(String.valueOf(pedidoSeleccionado.getIdPedido()));
        }
        if (fechaPedidoLabel != null) {
            fechaPedidoLabel.setText(pedidoSeleccionado.getFecha().format(FORMATO_FECHA));
        }
        if (proveedorPedidoLabel != null) {
            proveedorPedidoLabel.setText(pedidoSeleccionado.getNombreProveedor());
        }
        if (detalleTable != null) {
            try {
                List<DetallePedido> detalles = pedidoDAO.listarDetalles(pedidoSeleccionado.getIdPedido());
                pedidoSeleccionado.setDetalles(detalles);
                detalleTable.getItems().setAll(detalles);
                actualizarTotal();
            } catch (SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error", "No se pudieron cargar los productos del pedido.");
            }
        }
    }

    // Acciones de la vista principal
    private void abrirVistaPedido(String nombreVista, Pedido pedido) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(nombreVista));
            Parent vista = loader.load();
            PedidoController controller = loader.getController();
            controller.setPedidoSeleccionado(pedido);
            Stage ventana = new Stage();
            ventana.setTitle("Gestión de pedido");
            ventana.setScene(new Scene(vista));
            ventana.initModality(Modality.APPLICATION_MODAL);
            ventana.setResizable(false);
            ventana.showAndWait();
            actualizarPaginacionPedidos();
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo abrir la vista del pedido.");
        }
    }
    @FXML private void volverAlInicio() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/menu-view.fxml"));
            Stage ventana = (Stage) pedidosTable.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo volver a la pantalla principal.");
        }
    }
    @FXML private void nuevoPedido() {
        abrirVistaPedido("/resources/com/distribuidora/registrar-pedido-view.fxml", null);
    }

    // Agrega un producto a la lista del pedido (todavía no se guarda en la base de datos)
    @FXML private void agregarProducto() {
        Producto producto = productoComboBox.getValue();
        if (producto == null) {
            mostrarMensaje("Validación", "Seleccioná un producto.");
            return;
        }
        try {
            int cantidad = Integer.parseInt(cantidadField.getText().trim());
            BigDecimal precio = new BigDecimal(precioUnitarioField.getText().trim().replace(',', '.'))
                    .setScale(2, RoundingMode.HALF_UP);
            if (cantidad <= 0) {
                mostrarMensaje("Validación", "La cantidad debe ser mayor que cero.");
                return;
            }
            if (precio.compareTo(BigDecimal.ZERO) <= 0 || precio.compareTo(IMPORTE_MAXIMO) > 0) {
                mostrarMensaje("Validación", "El precio unitario no es válido.");
                return;
            }
            for (DetallePedido existente : detalleTable.getItems()) {
                if (existente.getIdProducto() == producto.getIdProducto()) {
                    mostrarMensaje("Validación",
                            "El producto ya está en el pedido. Quitalo y volvé a agregarlo con la cantidad correcta.");
                    return;
                }
            }
            if (producto.getStockActual() + cantidad > producto.getStockMaximo()) {
                mostrarMensaje("Validación",
                        "Con esa cantidad el stock de " + producto.getDescripcion()
                                + " superaría el stock máximo (" + producto.getStockMaximo()
                                + "). Stock actual: " + producto.getStockActual() + ".");
                return;
            }
            DetallePedido detalle = new DetallePedido(producto.getIdProducto(), cantidad, precio);
            if (detalle.getPrecioTotal().compareTo(IMPORTE_MAXIMO) > 0) {
                mostrarMensaje("Validación", "El importe del producto es demasiado grande.");
                return;
            }
            detalle.setDescripcionProducto(producto.getDescripcion());
            detalleTable.getItems().add(detalle);
            actualizarTotal();
            productoComboBox.setValue(null);
            cantidadField.clear();
            precioUnitarioField.clear();
        } catch (NumberFormatException e) {
            mostrarMensaje("Validación",
                    "La cantidad debe ser un número entero y el precio un número válido.");
        }
    }
    @FXML private void quitarProducto() {
        DetallePedido seleccionado = detalleTable.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarMensaje("Información", "Seleccioná un producto de la tabla para quitarlo.");
            return;
        }
        detalleTable.getItems().remove(seleccionado);
        actualizarTotal();
    }
    private void actualizarTotal() {
        if (totalLabel == null || detalleTable == null) {
            return;
        }
        BigDecimal total = BigDecimal.ZERO;
        for (DetallePedido detalle : detalleTable.getItems()) {
            total = total.add(detalle.getPrecioTotal());
        }
        totalLabel.setText(formatearImporte(total));
    }

    @FXML private void registrarPedido() {
        Proveedor proveedor = proveedorComboBox.getValue();
        if (proveedor == null) {
            mostrarMensaje("Validación", "Seleccioná un proveedor.");
            return;
        }
        if (detalleTable.getItems().isEmpty()) {
            mostrarMensaje("Validación", "Agregá al menos un producto al pedido.");
            return;
        }
        Pedido pedido = new Pedido(0, LocalDate.now(), proveedor.getIdProveedor());
        pedido.setDetalles(new ArrayList<>(detalleTable.getItems()));
        try {
            int idPedido = pedidoDAO.registrarPedido(pedido);
            mostrarMensaje("Registro exitoso",
                    "El pedido N° " + idPedido + " se registró correctamente y el stock fue actualizado.");
            cerrarVentana();
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudo registrar el pedido. No se realizó ningún cambio.");
        }
    }

    private void cerrarVentana() {
        if (detalleTable != null && detalleTable.getScene() != null) {
            Stage ventana = (Stage) detalleTable.getScene().getWindow();
            ventana.close();
        }
    }
    @FXML private void cancelar() {
        cerrarVentana();
    }

    private void configurarColumnaAcciones() {
        accionesColumn.setCellFactory(columna -> new TableCell<>() {
            private final Button accionesButton = new Button("⋮"); {
                accionesButton.setOnAction(event -> {
                    Pedido pedido = getTableView()
                            .getItems()
                            .get(getIndex());
                    ContextMenu menu = new ContextMenu();
                    MenuItem verItem = new MenuItem("Ver");
                    verItem.setOnAction(e ->
                            abrirVistaPedido("/resources/com/distribuidora/ver-pedido-view.fxml", pedido)
                    );
                    menu.getItems().add(verItem);
                    menu.show(accionesButton, javafx.geometry.Side.BOTTOM, 0, 0);
                });
            }
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : accionesButton);
            }
        });
    }

    private void actualizarPaginacionPedidos() {
        if (pedidosTable == null || paginacionPedidos == null) {
            return;
        }
        try {
            String filtro = buscarPedidoPedidosField == null
                    ? "" : buscarPedidoPedidosField.getText().trim();
            int cantidadPedidos = pedidoDAO.contarPedidos(filtro);
            int cantidadPaginas = (int) Math.ceil((double) cantidadPedidos / PEDIDOS_POR_PAGINA);
            cantidadPaginas = Math.max(1, cantidadPaginas);
            paginacionPedidos.setPageCount(cantidadPaginas);
            int paginaActual = Math.min(paginacionPedidos.getCurrentPageIndex(), cantidadPaginas - 1);
            if (paginacionPedidos.getCurrentPageIndex() != paginaActual) {
                paginacionPedidos.setCurrentPageIndex(paginaActual);
            } else {
                mostrarPaginaPedidos(paginaActual);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la lista de pedidos.");
        }
    }
    private void mostrarPaginaPedidos(int indicePagina) {
        try {
            String filtro = buscarPedidoPedidosField == null
                    ? "" : buscarPedidoPedidosField.getText();
            int offset = indicePagina * PEDIDOS_POR_PAGINA;
            List<Pedido> pedidos = pedidoDAO.listarPagina(PEDIDOS_POR_PAGINA, offset, filtro);
            pedidosTable.getItems().setAll(pedidos);
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron mostrar los pedidos.");
        }
    }
    @FXML private void filtrarPedidos() {
        paginacionPedidos.setCurrentPageIndex(0);
        actualizarPaginacionPedidos();
    }
}
