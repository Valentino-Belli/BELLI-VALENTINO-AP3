package com.distribuidora;

public class RolUsuario {

    private int idRolUsuario;
    private String nombreRol;

    public RolUsuario(int idRolUsuario, String nombreRol) {
        this.idRolUsuario = idRolUsuario;
        this.nombreRol = nombreRol;
    }

    public int getIdRolUsuario() {
        return idRolUsuario;
    }
    public String getNombreRol() {
        return nombreRol;
    }

    @Override
    public String toString() {
        return nombreRol;
    }
}

