package com.distribuidora;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.io.IOException;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;

public class MenuController {

    @FXML private VBox sidebar;
    @FXML private Label usuarioLabel;
    @FXML private Label rolUsuarioLabel;
    @FXML private Label fechaHoyLabel;
    @FXML private Button alertaStockButton;
    private final ProductoDAO productoDAO = new ProductoDAO();
    @FXML private VBox alertasStockBox;
    private static final int MAX_ALERTAS_MENU = 5;

    private Usuario usuarioActual;
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        usuarioLabel.setText(usuarioActual.getNombreUsuario());
        try {
            String nombreRol = usuarioDAO.buscarNombreRol(usuarioActual.getIdRolUsuario());
            rolUsuarioLabel.setText(nombreRol != null ? nombreRol : "Rol desconocido");
        } catch (SQLException e) {
            e.printStackTrace();
            rolUsuarioLabel.setText("No se pudo cargar el rol");
        }
    }

    // Mensaje emergente
    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    // Metodo que se ejecuta al abrir/refrescar la vista (Archivo FXML)
    @FXML private void initialize() {
        sidebar.setMinWidth(220);
        sidebar.setPrefWidth(220);
        sidebar.setMaxWidth(220);
        DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                "d 'de' MMMM 'de' yyyy",
                Locale.forLanguageTag("es-AR")
        );
        fechaHoyLabel.setText(LocalDate.now().format(formato));
        // Carga el usuario de la sesión (también al volver desde otras pantallas)
        Usuario usuario = Sesion.getUsuarioActual();
        if (usuario != null) {
            setUsuario(usuario);
        }
        actualizarAlertaStock();
    }

    @FXML private void abrirProductos() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/productos-view.fxml"));
            Stage ventana = (Stage) sidebar.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            System.out.println("No se pudo abrir la vista de productos.");
        }
    }
    @FXML private void abrirProveedores() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/proveedores-view.fxml"));
            Stage ventana = (Stage) sidebar.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            System.out.println("No se pudo abrir la vista de proveedores.");
        }
    }
    @FXML private void abrirClientes() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/clientes-view.fxml"));
            Stage ventana = (Stage) sidebar.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            System.out.println("No se pudo abrir la vista de clientes.");
        }
    }
    @FXML private void abrirUsuarios() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/usuarios-view.fxml"));
            Stage ventana = (Stage) sidebar.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            System.out.println("No se pudo abrir la vista de usuarios.");
        }
    }
    @FXML private void abrirPedidos() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/pedidos-view.fxml"));
            Stage ventana = (Stage) sidebar.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            System.out.println("No se pudo abrir la vista de pedidos.");
        }
    }
    @FXML private void abrirVentas() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/ventas-view.fxml"));
            Stage ventana = (Stage) sidebar.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            System.out.println("No se pudo abrir la vista de ventas.");
        }
    }
    @FXML private void abrirProductosStockBajo() {
        try {
            // Si no hay nada para reponer, se abre Productos sin filtro
            if (productoDAO.contarStockBajo() == 0) {
                abrirProductos();
                return;
            }
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/com/distribuidora/productos-view.fxml"));
            Parent vista = loader.load();
            ProductoController controller = loader.getController();
            controller.activarSoloStockBajo();
            Stage ventana = (Stage) sidebar.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException | NullPointerException | SQLException e) {
            e.printStackTrace();
            System.out.println("No se pudo abrir la vista de productos.");
        }
    }

    @FXML private void cerrarSesion() {
        try {
            Sesion.cerrarSesion();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/com/distribuidora/login-view.fxml"));
            Parent vista = loader.load();
            Stage ventana = (Stage) sidebar.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setTitle("Iniciar sesión");
        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo volver al inicio de sesión.");
        }
    }

    // Muestra cuántos productos llegaron al stock mínimo y cuáles son los más urgentes
    private void actualizarAlertaStock() {
        try {
            int cantidad = productoDAO.contarStockBajo();
            if (alertaStockButton != null) {
                if (cantidad == 0) {
                    alertaStockButton.setText("✔ Stock en orden");
                    alertaStockButton.setStyle("-fx-background-color: #DCFCE7; -fx-text-fill: #166534; -fx-cursor: hand;");
                } else {
                    alertaStockButton.setText("⚠ " + cantidad
                            + (cantidad == 1 ? " producto a reponer" : " productos a reponer"));
                    alertaStockButton.setStyle("-fx-background-color: #FEE2E2; -fx-text-fill: #991B1B; -fx-font-weight: bold; -fx-cursor: hand;");
                }
            }
            if (alertasStockBox != null) {
                alertasStockBox.getChildren().clear();
                List<Producto> productos = productoDAO.listarStockBajo(MAX_ALERTAS_MENU);
                for (Producto producto : productos) {
                    Label alerta = new Label(producto.getDescripcion() + ": "
                            + producto.getStockActual() + " (mín. " + producto.getStockMinimo() + ")");
                    alerta.setWrapText(true);
                    alerta.setMaxWidth(200);
                    // Sin stock en rojo fuerte, el resto en un rojo más suave
                    alerta.setStyle(producto.getStockActual() == 0
                            ? "-fx-text-fill: #991B1B; -fx-font-weight: bold; -fx-font-size: 12px;"
                            : "-fx-text-fill: #B45309; -fx-font-size: 12px;");
                    alertasStockBox.getChildren().add(alerta);
                }
                if (cantidad > productos.size()) {
                    Label mas = new Label("y " + (cantidad - productos.size()) + " más...");
                    mas.setStyle("-fx-text-fill: #64748B; -fx-font-size: 12px;");
                    alertasStockBox.getChildren().add(mas);
                }
                // Si no hay alertas, la caja no ocupa espacio en el menú
                alertasStockBox.setVisible(!alertasStockBox.getChildren().isEmpty());
                alertasStockBox.setManaged(!alertasStockBox.getChildren().isEmpty());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            if (alertaStockButton != null) {
                alertaStockButton.setText("");
            }
        }
    }
}