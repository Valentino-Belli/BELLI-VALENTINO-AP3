package com.distribuidora;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ClienteController {

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private Cliente clienteSeleccionado;

    // fx:id de la vista principal de cliente
    @FXML private TextField buscarClienteClientesField;
    @FXML private TableView<Cliente> clientesTable;
    @FXML private TableColumn<Cliente, Integer> codigoColumn;
    @FXML private TableColumn<Cliente, String> nombreColumn;
    @FXML private TableColumn<Cliente, String> apellidoColumn;
    @FXML private TableColumn<Cliente, String> dniColumn;
    @FXML private TableColumn<Cliente, String> telefonoColumn;
    @FXML private TableColumn<Cliente, String> emailColumn;
    @FXML private TableColumn<Cliente, String> direccionColumn;
    @FXML private TableColumn<Cliente, Object> accionesColumn;
    @FXML private Pagination paginacionClientes;
    private static final int CLIENTES_POR_PAGINA = 10;

    // fx:id de las vistas del cliente
    @FXML private TextField idClienteField;
    @FXML private TextField nombreClienteField;
    @FXML private TextField apellidoClienteField;
    @FXML private TextField dniClienteField;
    @FXML private TextField telefonoClienteField;
    @FXML private TextField emailClienteField;
    @FXML private TextField direccionClienteField;
    @FXML private Label nombreClienteLabel;


    // Mensaje emergente
    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    // Validacion de que el email tenga el formato correcto
    public static boolean esEmailValido(String email) {
        String EMAIL_REGEX = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
        Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);
        if (email == null) {
            return false;
        }
        Matcher matcher = EMAIL_PATTERN.matcher(email);
        return matcher.matches();
    }
    public static boolean esDniValido(String dni) {
        try {
            if (dni.length() == 8) {
                int dniValido = Integer.parseInt(dni);
                return true;
            } else {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Metodo que se ejecuta al abrir/refrescar la vista (Archivo FXML)
    @FXML private void initialize() {
        if (clientesTable == null) {
            return;
        }
        if (clientesTable != null) {
            clientesTable.setItems(FXCollections.observableArrayList());
            codigoColumn.setCellValueFactory(new PropertyValueFactory<>("idCliente"));
            nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombreCliente"));
            apellidoColumn.setCellValueFactory(new PropertyValueFactory<>("apellidoCliente"));
            dniColumn.setCellValueFactory(new PropertyValueFactory<>("dni"));
            telefonoColumn.setCellValueFactory(new PropertyValueFactory<>("telefono"));
            emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
            direccionColumn.setCellValueFactory(new PropertyValueFactory<>("direccion"));
            configurarColumnaAcciones();
            if (paginacionClientes != null) {
                paginacionClientes.currentPageIndexProperty().addListener(
                        (observable, anterior, nuevo) ->
                                mostrarPaginaClientes(nuevo.intValue())
                );
            }
        }
        actualizarPaginacionClientes();
    }

    // Creacion del cliente que se haya seleccionado en la columna Acciones
    public void setClienteSeleccionado(Cliente cliente) {
        this.clienteSeleccionado = cliente;
        cargarDatosCliente();
    }
    private void cargarDatosCliente() {
        if (clienteSeleccionado == null) {
            return;
        }
        if (idClienteField != null) {
            idClienteField.setText(String.valueOf(clienteSeleccionado.getIdCliente()));
        }
        if (nombreClienteField != null) {
            nombreClienteField.setText(clienteSeleccionado.getNombreCliente());
        }
        if (nombreClienteLabel != null) {
            nombreClienteLabel.setText(clienteSeleccionado.getNombreCliente());
        }
        if (apellidoClienteField != null) {
            apellidoClienteField.setText(clienteSeleccionado.getApellidoCliente());
        }
        if (dniClienteField != null) {
            dniClienteField.setText(clienteSeleccionado.getDni());
        }
        if (telefonoClienteField != null) {
            telefonoClienteField.setText(clienteSeleccionado.getTelefono());
        }
        if (emailClienteField != null) {
            emailClienteField.setText(clienteSeleccionado.getEmail());
        }
        if (direccionClienteField != null) {
            direccionClienteField.setText(clienteSeleccionado.getDireccion());
        }
    }

    // Acciones de la vista principal
    private void abrirVistaCliente(String nombreVista, Cliente cliente) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(nombreVista));
            Parent vista = loader.load();
            ClienteController controller = loader.getController();
            controller.setClienteSeleccionado(cliente);
            Stage ventana = new Stage();
            ventana.setTitle("Gestión de cliente");
            ventana.setScene(new Scene(vista));
            ventana.initModality(Modality.APPLICATION_MODAL);
            ventana.setResizable(false);
            ventana.showAndWait();
            actualizarPaginacionClientes();
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo abrir la vista del cliente.");
        }
    }
    @FXML private void volverAlInicio() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/menu-view.fxml"));
            Stage ventana = (Stage) clientesTable.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo volver a la pantalla principal.");
        }
    }
    @FXML private void nuevoCliente() {
        abrirVistaCliente("/resources/com/distribuidora/registrar-cliente-view.fxml", null);
    }
    @FXML private void registrarCliente() {
        ClienteDAO clienteDAO = new ClienteDAO();
        String nombre = nombreClienteField.getText().trim();
        String apellido = apellidoClienteField.getText().trim();
        String dni = dniClienteField.getText().trim();
        String telefono = telefonoClienteField.getText().trim();
        String email = emailClienteField.getText().trim();
        String direccion = direccionClienteField.getText().trim();
        if (nombre.isEmpty() ||
                apellido.isEmpty() ||
                dni.isEmpty() ||
                telefono.isEmpty() ||
                email.isEmpty() ||
                direccion.isEmpty()) {
            mostrarMensaje("Validación", "Completá todos los campos obligatorios.");
            return;
        }
        if (nombre.length() < 2 || nombre.length() > 50) {
            mostrarMensaje("Validación",
                    "El nombre del cliente debe tener 2 caracteres como mínimo y 50 como máximo");
            return;
        }
        if (apellido.length() < 2 || apellido.length() > 50) {
            mostrarMensaje("Validación",
                    "El apellido del cliente debe tener 2 caracteres como mínimo y 50 como máximo");
            return;
        }
        if (!esDniValido(dni)) {
            mostrarMensaje("Validación",
                    "El dni del cliente debe tener 8 caracteres numericos");
            return;
        }
        try {
            Cliente dniEncontrado = clienteDAO.buscarPorDni(dni);
            if (dniEncontrado != null) {
                mostrarMensaje("Validación", "El dni del cliente ya esta en uso.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo comprobar el dni del cliente.");
            return;
        }
        if (telefono.length() < 8 || telefono.length() > 20) {
            mostrarMensaje("Validación",
                    "El telefono del cliente debe tener 8 caracteres como mínimo y 20 como máximo");
            return;
        }
        if (!esEmailValido(email)) {
            mostrarMensaje("Validación", "El formato del email es inválido.");
            return;
        }
        try {
            Cliente emailEncontrado = clienteDAO.buscarPorEmail(email);
            if (emailEncontrado != null) {
                mostrarMensaje("Validación", "El email del cliente ya esta en uso.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo comprobar el email del cliente.");
            return;
        }
        if (direccion.length() < 6 || direccion.length() > 50) {
            mostrarMensaje("Validación",
                    "La direccion del cliente debe tener 6 caracteres como mínimo y 50 como máximo");
            return;
        }
        Cliente cliente = new Cliente(
                0,
                nombre,
                apellido,
                dni,
                telefono,
                email,
                direccion
        );
        try {
            int filasAfectadas = clienteDAO.insertar(cliente);
            if (filasAfectadas == 1) {
                mostrarMensaje("Registro exitoso", "El cliente se registró correctamente.");
                Stage ventana = (Stage) nombreClienteField
                        .getScene().getWindow();
                ventana.close();
            } else {
                mostrarMensaje("Registro", "No se pudo registrar el cliente.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "Ocurrió un error al registrar el cliente.");
        }
    }
    @FXML private void eliminarCliente() {
        if (clienteSeleccionado == null) {
            mostrarMensaje("Error", "No se seleccionó ningún cliente.");
            return;
        }
        try {
            int filasAfectadas = clienteDAO.eliminar(clienteSeleccionado.getIdCliente());
            if (filasAfectadas == 0) {
                mostrarMensaje("Información", "El cliente seleccionado no existe.");
                return;
            }
            actualizarPaginacionClientes();
            mostrarMensaje("Éxito", "Cliente eliminado correctamente.");
            cerrarVentana();
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudo eliminar el cliente. Puede estar " + "asociado a otros registros.");
        }
    }
    @FXML private void modificarCliente() {
        if (clienteSeleccionado == null) {
            mostrarMensaje("Error", "No se seleccionó ningún cliente.");
            return;
        }
        String nombre = nombreClienteField.getText().trim();
        String apellido = apellidoClienteField.getText().trim();
        String dni = dniClienteField.getText().trim();
        String telefono = telefonoClienteField.getText().trim();
        String email = emailClienteField.getText().trim();
        String direccion = direccionClienteField.getText().trim();
        if (nombre.isEmpty() ||
                apellido.isEmpty() ||
                dni.isEmpty() ||
                telefono.isEmpty() ||
                email.isEmpty() ||
                direccion.isEmpty()) {
            mostrarMensaje("Validación", "Completá todos los campos obligatorios.");
            return;
        }
        if (nombre.length() < 2 || nombre.length() > 50) {
            mostrarMensaje("Validación",
                    "El nombre del cliente debe tener 2 caracteres como mínimo y 50 como máximo");
            return;
        }
        if (apellido.length() < 2 || apellido.length() > 50) {
            mostrarMensaje("Validación",
                    "El apellido del cliente debe tener 2 caracteres como mínimo y 50 como máximo");
            return;
        }
        if (!esDniValido(dni)) {
            mostrarMensaje("Validación",
                    "El dni del cliente debe tener 8 caracteres numericos");
            return;
        }
        try {
            Cliente dniEncontrado = clienteDAO.buscarPorDni(dni);
            if (dniEncontrado != null && dniEncontrado.getIdCliente() != clienteSeleccionado.getIdCliente()) {
                mostrarMensaje("Validación", "El dni del cliente ya esta en uso.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo comprobar el dni del cliente.");
            return;
        }
        if (telefono.length() < 8 || telefono.length() > 20) {
            mostrarMensaje("Validación",
                    "El telefono del cliente debe tener 8 caracteres como mínimo y 20 como máximo");
            return;
        }
        if (!esEmailValido(email)) {
            mostrarMensaje("Validación", "El formato del email es inválido.");
            return;
        }
        try {
            Cliente emailEncontrado = clienteDAO.buscarPorEmail(email);
            if (emailEncontrado != null && emailEncontrado.getIdCliente() != clienteSeleccionado.getIdCliente()) {
                mostrarMensaje("Validación", "El email del cliente ya esta en uso.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo comprobar el email del cliente.");
            return;
        }
        if (direccion.length() < 6 || direccion.length() > 50) {
            mostrarMensaje("Validación",
                    "La direccion del cliente debe tener 6 caracteres como mínimo y 50 como máximo");
            return;
        }
        Cliente clienteActualizado = new Cliente();
        clienteActualizado.setIdCliente(clienteSeleccionado.getIdCliente());
        clienteActualizado.setNombreCliente(nombre);
        clienteActualizado.setApellidoCliente(apellido);
        clienteActualizado.setDni(dni);
        clienteActualizado.setTelefono(telefono);
        clienteActualizado.setEmail(email);
        clienteActualizado.setDireccion(direccion);
        try {
            int filasAfectadas = clienteDAO.actualizar(clienteActualizado);
            if (filasAfectadas == 0) {
                mostrarMensaje("Información",
                        "No se modificaron filas. Verificá que "
                                + "el cliente exista y que los datos hayan cambiado.");
                return;
            }
            actualizarPaginacionClientes();
            mostrarMensaje("Éxito",
                    "Cliente actualizado correctamente.");
            cerrarVentana();
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudieron guardar los cambios. ");
        }
    }

    private void cerrarVentana() {
        if (nombreClienteField != null && nombreClienteField.getScene() != null) {
            Stage ventana = (Stage) nombreClienteField.getScene().getWindow();
            ventana.close();
        } else if (nombreClienteLabel != null && nombreClienteLabel.getScene() != null) {
            Stage ventana = (Stage) nombreClienteLabel.getScene().getWindow();
            ventana.close();
        }
    }
    @FXML private void cancelar() {
        cerrarVentana();
    }

    private void configurarColumnaAcciones() {
        accionesColumn.setCellFactory(columna -> new TableCell<>() {
            private final Button accionesButton = new Button("⋮"); {
                accionesButton.setOnAction(event -> {
                    Cliente cliente = getTableView()
                            .getItems()
                            .get(getIndex());
                    ContextMenu menu = new ContextMenu();
                    MenuItem verItem = new MenuItem("Ver");
                    MenuItem editarItem = new MenuItem("Editar");
                    MenuItem eliminarItem = new MenuItem("Eliminar");
                    verItem.setOnAction(e ->
                            abrirVistaCliente("/resources/com/distribuidora/ver-cliente-view.fxml", cliente)
                    );
                    editarItem.setOnAction(e ->
                            abrirVistaCliente("/resources/com/distribuidora/editar-cliente-view.fxml", cliente)
                    );
                    eliminarItem.setOnAction(e ->
                            abrirVistaCliente("/resources/com/distribuidora/eliminar-cliente-view.fxml", cliente)
                    );
                    menu.getItems().addAll(
                            verItem,
                            editarItem,
                            eliminarItem
                    );
                    menu.show(accionesButton, javafx.geometry.Side.BOTTOM, 0, 0);
                });
            }
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : accionesButton);
            }
        });
    }

    private void actualizarPaginacionClientes() {
        if (clientesTable == null || paginacionClientes == null) {
            return;
        }
        try {
            String filtro = buscarClienteClientesField == null
                    ? "" : buscarClienteClientesField.getText().trim();
            int cantidadClientes = clienteDAO.contarClientes(filtro);
            int cantidadPaginas = (int) Math.ceil((double) cantidadClientes / CLIENTES_POR_PAGINA);
            cantidadPaginas = Math.max(1, cantidadPaginas);
            paginacionClientes.setPageCount(cantidadPaginas);
            int paginaActual = Math.min(paginacionClientes.getCurrentPageIndex(), cantidadPaginas - 1);
            if (paginacionClientes.getCurrentPageIndex() != paginaActual) {
                paginacionClientes.setCurrentPageIndex(paginaActual);
            } else {
                mostrarPaginaClientes(paginaActual);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la lista de clientes.");
        }
    }
    private void mostrarPaginaClientes(int indicePagina) {
        try {
            String filtro = buscarClienteClientesField.getText();
            int offset = indicePagina * CLIENTES_POR_PAGINA;
            List<Cliente> clientes = clienteDAO.listarPagina(CLIENTES_POR_PAGINA, offset, filtro);
            clientesTable.getItems().setAll(clientes);
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron mostrar los clientes.");
        }
    }
    @FXML private void filtrarClientes() {
        paginacionClientes.setCurrentPageIndex(0);
        actualizarPaginacionClientes();
    }
}
