package com.distribuidora;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProveedorDAO {

    // Buscar proveedor por email
    public Proveedor buscarPorEmail(String email) throws SQLException {
        String sql = """
            SELECT idProveedor, nombreProveedor, telefono, email, direccion
            FROM proveedor
            WHERE email = ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, email);
            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {
                    return mapearProveedor(resultado);
                }
                return null;
            }
        }
    }

    // Convierte una fila de la base de datos en un objeto Proveedor
    private Proveedor mapearProveedor(ResultSet resultado) throws SQLException {
        Proveedor proveedor = new Proveedor();
        proveedor.setIdProveedor(resultado.getInt("idProveedor"));
        proveedor.setNombreProveedor(resultado.getString("nombreProveedor"));
        proveedor.setTelefono(resultado.getString("telefono"));
        proveedor.setEmail(resultado.getString("email"));
        proveedor.setDireccion(resultado.getString("direccion"));
        return proveedor;
    }

    // Registrar un proveedor nuevo
    public int insertar(Proveedor proveedor) throws SQLException {
        String sql = """
            INSERT INTO proveedor (
                nombreProveedor,
                telefono,
                email,
                direccion
            ) VALUES (?, ?, ?, ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, proveedor.getNombreProveedor());
            sentencia.setString(2, proveedor.getTelefono());
            sentencia.setString(3, proveedor.getEmail());
            sentencia.setString(4, proveedor.getDireccion());
            return sentencia.executeUpdate();
        }
    }

    // Eliminar un proveedor
    public int eliminar(int idProveedor) throws SQLException {
        String sql = "DELETE FROM proveedor WHERE idProveedor = ?";
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idProveedor);
            return sentencia.executeUpdate();
        }
    }

    // Actualizar un proveedor
    public int actualizar(Proveedor proveedor) throws SQLException {
        String sql = """
            UPDATE proveedor
            SET nombreProveedor = ?,
                telefono = ?,
                email = ?,
                direccion = ?
            WHERE idProveedor = ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, proveedor.getNombreProveedor());
            sentencia.setString(2, proveedor.getTelefono());
            sentencia.setString(3, proveedor.getEmail());
            sentencia.setString(4, proveedor.getDireccion());
            sentencia.setInt(5, proveedor.getIdProveedor());
            return sentencia.executeUpdate();
        }
    }

    // Listar proveedores por página y aplicar filtro
    public List<Proveedor> listarPagina(
            int limite, int offset, String filtro) throws SQLException {
        List<Proveedor> proveedores = new ArrayList<>();
        String sql = """
            SELECT idProveedor, nombreProveedor, telefono, email, direccion
            FROM proveedor
            WHERE (? = ''
                   OR CAST(idProveedor AS CHAR) LIKE ?
                   OR nombreProveedor LIKE ?)
            ORDER BY idProveedor
            LIMIT ? OFFSET ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            for (int i = 2; i <= 3; i++) {
                sentencia.setString(i, patron);
            }
            sentencia.setInt(4, limite);
            sentencia.setInt(5, offset);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    proveedores.add(mapearProveedor(resultado));
                }
            }
        }
        return proveedores;
    }

    // Contar proveedores que coinciden con el filtro
    public int contarProveedores(String filtro) throws SQLException {
        String sql = """
            SELECT COUNT(*)
            FROM proveedor
            WHERE (? = ''
                   OR CAST(idProveedor AS CHAR) LIKE ?
                   OR nombreProveedor LIKE ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            for (int i = 2; i <= 3; i++) {
                sentencia.setString(i, patron);
            }
            try (ResultSet resultado = sentencia.executeQuery()) {
                resultado.next();
                return resultado.getInt(1);
            }
        }
    }
}