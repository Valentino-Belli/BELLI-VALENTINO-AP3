package com.distribuidora;

public class EstadoVenta {

    private int idEstadoVenta;
    private String nombreEstado;

    public EstadoVenta(int idEstadoVenta, String nombreEstado) {
        this.idEstadoVenta = idEstadoVenta;
        this.nombreEstado = nombreEstado;
    }

    public int getIdEstadoVenta() {
        return idEstadoVenta;
    }
    public String getNombreEstado() {
        return nombreEstado;
    }

    @Override
    public String toString() {
        return nombreEstado;
    }
}