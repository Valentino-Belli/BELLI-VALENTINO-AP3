package com.distribuidora;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ProveedorController {

    private final ProveedorDAO proveedorDAO = new ProveedorDAO();
    private Proveedor proveedorSeleccionado;

    // fx:id de la vista principal de proveedores
    @FXML private TextField buscarProveedorProveedoresField;
    @FXML private TableView<Proveedor> proveedoresTable;
    @FXML private TableColumn<Proveedor, Integer> codigoColumn;
    @FXML private TableColumn<Proveedor, String> nombreColumn;
    @FXML private TableColumn<Proveedor, String> telefonoColumn;
    @FXML private TableColumn<Proveedor, String> emailColumn;
    @FXML private TableColumn<Proveedor, String> direccionColumn;
    @FXML private TableColumn<Proveedor, Object> accionesColumn;
    @FXML private Pagination paginacionProveedores;
    private static final int PROVEEDORES_POR_PAGINA = 10;

    // fx:id de las vistas del proveedor
    @FXML private TextField idProveedorField;
    @FXML private TextField nombreProveedorField;
    @FXML private TextField telefonoProveedorField;
    @FXML private TextField emailProveedorField;
    @FXML private TextField direccionProveedorField;
    @FXML private Label nombreProveedorLabel;


    // Mensaje emergente
    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    // Validacion de que el email tenga el formato correcto
    public static boolean esEmailValido(String email) {
        String EMAIL_REGEX = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
        Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);
        if (email == null) {
            return false;
        }
        Matcher matcher = EMAIL_PATTERN.matcher(email);
        return matcher.matches();
    }

    // Metodo que se ejecuta al abrir/refrescar la vista (Archivo FXML)
    @FXML private void initialize() {
        if (proveedoresTable == null) {
            return;
        }
        if (proveedoresTable != null) {
            proveedoresTable.setItems(FXCollections.observableArrayList());
            codigoColumn.setCellValueFactory(new PropertyValueFactory<>("idProveedor"));
            nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombreProveedor"));
            telefonoColumn.setCellValueFactory(new PropertyValueFactory<>("telefono"));
            emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
            direccionColumn.setCellValueFactory(new PropertyValueFactory<>("direccion"));
            configurarColumnaAcciones();
            if (paginacionProveedores != null) {
                paginacionProveedores.currentPageIndexProperty().addListener(
                        (observable, anterior, nuevo) ->
                                mostrarPaginaProveedores(nuevo.intValue())
                );
            }
        }
        actualizarPaginacionProveedores();
    }

    // Creacion del proveedor que se haya seleccionado en la columna Acciones
    public void setProveedorSeleccionado(Proveedor proveedor) {
        this.proveedorSeleccionado = proveedor;
        cargarDatosProveedor();
    }
    private void cargarDatosProveedor() {
        if (proveedorSeleccionado == null) {
            return;
        }
        if (idProveedorField != null) {
            idProveedorField.setText(String.valueOf(proveedorSeleccionado.getIdProveedor()));
        }
        if (nombreProveedorField != null) {
            nombreProveedorField.setText(proveedorSeleccionado.getNombreProveedor());
        }
        if (nombreProveedorLabel != null) {
            nombreProveedorLabel.setText(proveedorSeleccionado.getNombreProveedor());
        }
        if (telefonoProveedorField != null) {
            telefonoProveedorField.setText(proveedorSeleccionado.getTelefono());
        }
        if (emailProveedorField != null) {
            emailProveedorField.setText(proveedorSeleccionado.getEmail());
        }
        if (direccionProveedorField != null) {
            direccionProveedorField.setText(proveedorSeleccionado.getDireccion());
        }
    }

    // Acciones de la vista principal
    private void abrirVistaProveedor(String nombreVista, Proveedor proveedor) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(nombreVista));
            Parent vista = loader.load();
            ProveedorController controller = loader.getController();
            controller.setProveedorSeleccionado(proveedor);
            Stage ventana = new Stage();
            ventana.setTitle("Gestión de proveedor");
            ventana.setScene(new Scene(vista));
            ventana.initModality(Modality.APPLICATION_MODAL);
            ventana.setResizable(false);
            ventana.showAndWait();
            actualizarPaginacionProveedores();
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo abrir la vista del proveedor.");
        }
    }
    @FXML private void volverAlInicio() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/menu-view.fxml"));
            Stage ventana = (Stage) proveedoresTable.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo volver a la pantalla principal.");
        }
    }
    @FXML private void nuevoProveedor() {
        abrirVistaProveedor("/resources/com/distribuidora/registrar-proveedor-view.fxml", null);
    }
    @FXML private void registrarProveedor() {
        ProveedorDAO proveedorDAO = new ProveedorDAO();
        String nombre = nombreProveedorField.getText().trim();
        String telefono = telefonoProveedorField.getText().trim();
        String email = emailProveedorField.getText().trim();
        String direccion = direccionProveedorField.getText().trim();
        if (nombre.isEmpty() ||
                telefono.isEmpty() ||
                email.isEmpty() ||
                direccion.isEmpty()) {
            mostrarMensaje("Validación", "Completá todos los campos obligatorios.");
            return;
        }
        if (nombre.length() < 2 || nombre.length() > 50) {
            mostrarMensaje("Validación",
                    "El nombre del proveedor debe tener 2 caracteres como mínimo y 50 como máximo");
            return;
        }
        if (telefono.length() < 8 || telefono.length() > 20) {
            mostrarMensaje("Validación",
                    "El telefono del cliente debe tener 8 caracteres como mínimo y 20 como máximo");
            return;
        }
        if (!esEmailValido(email)) {
            mostrarMensaje("Validación", "El formato del email es inválido.");
            return;
        }
        try {
            Proveedor emailEncontrado = proveedorDAO.buscarPorEmail(email);
            if (emailEncontrado != null) {
                mostrarMensaje("Validación", "El email del proveedor ya esta en uso.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo comprobar el email del proveedor.");
            return;
        }
        if (direccion.length() < 6 || direccion.length() > 50) {
            mostrarMensaje("Validación",
                    "La direccion del proveedor debe tener 6 caracteres como mínimo y 50 como máximo");
            return;
        }
        Proveedor proveedor = new Proveedor(
                0,
                nombre,
                telefono,
                email,
                direccion
        );
        try {
            int filasAfectadas = proveedorDAO.insertar(proveedor);
            if (filasAfectadas == 1) {
                mostrarMensaje("Registro exitoso", "El proveedor se registró correctamente.");
                Stage ventana = (Stage) nombreProveedorField
                        .getScene().getWindow();
                ventana.close();
            } else {
                mostrarMensaje("Registro", "No se pudo registrar el proveedor.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "Ocurrió un error al registrar el proveedor.");
        }
    }
    @FXML private void eliminarProveedor() {
        if (proveedorSeleccionado == null) {
            mostrarMensaje("Error", "No se seleccionó ningún proveedor.");
            return;
        }
        try {
            int filasAfectadas = proveedorDAO.eliminar(proveedorSeleccionado.getIdProveedor());
            if (filasAfectadas == 0) {
                mostrarMensaje("Información", "El proveedor seleccionado no existe.");
                return;
            }
            actualizarPaginacionProveedores();
            mostrarMensaje("Éxito", "Proveedor eliminado correctamente.");
            cerrarVentana();
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudo eliminar el proveedor. Puede estar " + "asociado a otros registros.");
        }
    }
    @FXML private void modificarProveedor() {
        if (proveedorSeleccionado == null) {
            mostrarMensaje("Error", "No se seleccionó ningún proveedor.");
            return;
        }
        String nombre = nombreProveedorField.getText().trim();
        String telefono = telefonoProveedorField.getText().trim();
        String email = emailProveedorField.getText().trim();
        String direccion = direccionProveedorField.getText().trim();
        if (nombre.isEmpty() ||
                telefono.isEmpty() ||
                email.isEmpty() ||
                direccion.isEmpty()) {
            mostrarMensaje("Validación", "Completá todos los campos obligatorios.");
            return;
        }
        if (nombre.length() < 2 || nombre.length() > 50) {
            mostrarMensaje("Validación",
                    "El nombre del proveedor debe tener 2 caracteres como mínimo y 50 como máximo");
            return;
        }
        if (telefono.length() < 8 || telefono.length() > 20) {
            mostrarMensaje("Validación",
                    "El telefono del proveedor debe tener 8 caracteres como mínimo y 20 como máximo");
            return;
        }
        if (!esEmailValido(email)) {
            mostrarMensaje("Validación", "El formato del email es inválido.");
            return;
        }
        try {
            Proveedor emailEncontrado = proveedorDAO.buscarPorEmail(email);
            if (emailEncontrado != null && emailEncontrado.getIdProveedor() != proveedorSeleccionado.getIdProveedor()) {
                mostrarMensaje("Validación", "El email del proveedor ya esta en uso.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo comprobar el email del proveedor.");
            return;
        }
        if (direccion.length() < 6 || direccion.length() > 50) {
            mostrarMensaje("Validación",
                    "La direccion del proveedor debe tener 6 caracteres como mínimo y 50 como máximo");
            return;
        }
        Proveedor proveedorActualizado = new Proveedor();
        proveedorActualizado.setIdProveedor(proveedorSeleccionado.getIdProveedor());
        proveedorActualizado.setNombreProveedor(nombre);
        proveedorActualizado.setTelefono(telefono);
        proveedorActualizado.setEmail(email);
        proveedorActualizado.setDireccion(direccion);
        try {
            int filasAfectadas = proveedorDAO.actualizar(proveedorActualizado);
            if (filasAfectadas == 0) {
                mostrarMensaje("Información",
                        "No se modificaron filas. Verificá que "
                                + "el proveedor exista y que los datos hayan cambiado.");
                return;
            }
            actualizarPaginacionProveedores();
            mostrarMensaje("Éxito",
                    "Proveedor actualizado correctamente.");
            cerrarVentana();
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudieron guardar los cambios. ");
        }
    }

    private void cerrarVentana() {
        if (nombreProveedorField != null && nombreProveedorField.getScene() != null) {
            Stage ventana = (Stage) nombreProveedorField.getScene().getWindow();
            ventana.close();
        } else if (nombreProveedorLabel != null && nombreProveedorLabel.getScene() != null) {
            Stage ventana = (Stage) nombreProveedorLabel.getScene().getWindow();
            ventana.close();
        }
    }
    @FXML private void cancelar() {
        cerrarVentana();
    }

    private void configurarColumnaAcciones() {
        accionesColumn.setCellFactory(columna -> new TableCell<>() {
            private final Button accionesButton = new Button("⋮"); {
                accionesButton.setOnAction(event -> {
                    Proveedor proveedor = getTableView()
                            .getItems()
                            .get(getIndex());
                    ContextMenu menu = new ContextMenu();
                    MenuItem verItem = new MenuItem("Ver");
                    MenuItem editarItem = new MenuItem("Editar");
                    MenuItem eliminarItem = new MenuItem("Eliminar");
                    verItem.setOnAction(e ->
                            abrirVistaProveedor("/resources/com/distribuidora/ver-proveedor-view.fxml", proveedor)
                    );
                    editarItem.setOnAction(e ->
                            abrirVistaProveedor("/resources/com/distribuidora/editar-proveedor-view.fxml", proveedor)
                    );
                    eliminarItem.setOnAction(e ->
                            abrirVistaProveedor("/resources/com/distribuidora/eliminar-proveedor-view.fxml", proveedor)
                    );
                    menu.getItems().addAll(
                            verItem,
                            editarItem,
                            eliminarItem
                    );
                    menu.show(accionesButton, javafx.geometry.Side.BOTTOM, 0, 0);
                });
            }
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : accionesButton);
            }
        });
    }

    private void actualizarPaginacionProveedores() {
        if (proveedoresTable == null || paginacionProveedores == null) {
            return;
        }
        try {
            String filtro = buscarProveedorProveedoresField == null
                    ? "" : buscarProveedorProveedoresField.getText().trim();
            int cantidadProveedores = proveedorDAO.contarProveedores(filtro);
            int cantidadPaginas = (int) Math.ceil((double) cantidadProveedores / PROVEEDORES_POR_PAGINA);
            cantidadPaginas = Math.max(1, cantidadPaginas);
            paginacionProveedores.setPageCount(cantidadPaginas);
            int paginaActual = Math.min(paginacionProveedores.getCurrentPageIndex(), cantidadPaginas - 1);
            if (paginacionProveedores.getCurrentPageIndex() != paginaActual) {
                paginacionProveedores.setCurrentPageIndex(paginaActual);
            } else {
                mostrarPaginaProveedores(paginaActual);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la lista de proveedores.");
        }
    }
    private void mostrarPaginaProveedores(int indicePagina) {
        try {
            String filtro = buscarProveedorProveedoresField.getText();
            int offset = indicePagina * PROVEEDORES_POR_PAGINA;
            List<Proveedor> proveedores = proveedorDAO.listarPagina(PROVEEDORES_POR_PAGINA, offset, filtro);
            proveedoresTable.getItems().setAll(proveedores);
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron mostrar los proveedores.");
        }
    }
    @FXML private void filtrarProveedores() {
        paginacionProveedores.setCurrentPageIndex(0);
        actualizarPaginacionProveedores();
    }
}

