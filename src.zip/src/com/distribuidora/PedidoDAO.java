package com.distribuidora;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    // Registra el pedido, sus detalles, suma el stock y guarda el historial.
    public int registrarPedido(Pedido pedido) throws SQLException {
        if (pedido.getDetalles() == null || pedido.getDetalles().isEmpty()) {
            throw new SQLException("El pedido no tiene productos.");
        }
        String sqlPedido = """
            INSERT INTO pedido (fecha, idProveedor)
            VALUES (?, ?)
            """;
        String sqlDetalle = """
            INSERT INTO detalle_pedido
                (idPedido, idProducto, cantidad, precioUnitario, precioTotal)
            VALUES (?, ?, ?, ?, ?)
            """;
        String sqlStock = """
            UPDATE producto
            SET stockActual = stockActual + ?
            WHERE idProducto = ?
            """;
        String sqlHistorial = """
            INSERT INTO historial
                (fecha, idProducto, cantidad, tipoMovimiento)
            VALUES (CURRENT_TIMESTAMP, ?, ?, ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar()) {
            conexion.setAutoCommit(false);
            try {
                int idPedido;
                try (PreparedStatement sentencia = conexion.prepareStatement(
                        sqlPedido, Statement.RETURN_GENERATED_KEYS)) {
                    sentencia.setDate(1, Date.valueOf(pedido.getFecha()));
                    sentencia.setInt(2, pedido.getIdProveedor());
                    sentencia.executeUpdate();
                    try (ResultSet claves = sentencia.getGeneratedKeys()) {
                        if (!claves.next()) {
                            throw new SQLException("No se pudo obtener el id del pedido.");
                        }
                        idPedido = claves.getInt(1);
                    }
                }
                for (DetallePedido detalle : pedido.getDetalles()) {
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlDetalle)) {
                        sentencia.setInt(1, idPedido);
                        sentencia.setInt(2, detalle.getIdProducto());
                        sentencia.setInt(3, detalle.getCantidad());
                        sentencia.setBigDecimal(4, detalle.getPrecioUnitario());
                        sentencia.setBigDecimal(5, detalle.getPrecioTotal());
                        sentencia.executeUpdate();
                    }
                    int filas;
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlStock)) {
                        sentencia.setInt(1, detalle.getCantidad());
                        sentencia.setInt(2, detalle.getIdProducto());
                        filas = sentencia.executeUpdate();
                    }
                    if (filas == 0) {
                        throw new SQLException("El producto con id "
                                + detalle.getIdProducto() + " no existe.");
                    }
                    try (PreparedStatement sentencia = conexion.prepareStatement(sqlHistorial)) {
                        sentencia.setInt(1, detalle.getIdProducto());
                        sentencia.setInt(2, detalle.getCantidad());
                        sentencia.setString(3, "Ingreso");
                        sentencia.executeUpdate();
                    }
                }
                conexion.commit();
                pedido.setIdPedido(idPedido);
                return idPedido;
            } catch (SQLException e) {
                conexion.rollback();
                throw e;
            } finally {
                conexion.setAutoCommit(true);
            }
        }
    }

    // Lista los pedidos para la paginación de las tablas, respetando filtros
    public List<Pedido> listarPagina(
            int limite, int offset, String filtro) throws SQLException {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = """
            SELECT p.idPedido, p.fecha, p.idProveedor, pr.nombreProveedor
            FROM pedido p
            INNER JOIN proveedor pr
                ON p.idProveedor = pr.idProveedor
            WHERE (? = ''
                   OR CAST(p.idPedido AS CHAR) LIKE ?
                   OR pr.nombreProveedor LIKE ?)
            ORDER BY p.idPedido DESC
            LIMIT ? OFFSET ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            sentencia.setString(2, patron);
            sentencia.setString(3, patron);
            sentencia.setInt(4, limite);
            sentencia.setInt(5, offset);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    Pedido pedido = new Pedido();
                    pedido.setIdPedido(resultado.getInt("idPedido"));
                    pedido.setFecha(resultado.getDate("fecha").toLocalDate());
                    pedido.setIdProveedor(resultado.getInt("idProveedor"));
                    pedido.setNombreProveedor(resultado.getString("nombreProveedor"));
                    pedidos.add(pedido);
                }
            }
        }
        return pedidos;
    }

    // Calcula cuantos pedidos hay para determinar la cantidad de páginas
    public int contarPedidos(String filtro) throws SQLException {
        String sql = """
            SELECT COUNT(*)
            FROM pedido p
            INNER JOIN proveedor pr
                ON p.idProveedor = pr.idProveedor
            WHERE (? = ''
                   OR CAST(p.idPedido AS CHAR) LIKE ?
                   OR pr.nombreProveedor LIKE ?)
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            String patron = "%" + busqueda + "%";
            sentencia.setString(1, busqueda);
            sentencia.setString(2, patron);
            sentencia.setString(3, patron);
            try (ResultSet resultado = sentencia.executeQuery()) {
                resultado.next();
                return resultado.getInt(1);
            }
        }
    }

    // Recupera los detalles (productos) de un pedido
    public List<DetallePedido> listarDetalles(int idPedido) throws SQLException {
        List<DetallePedido> detalles = new ArrayList<>();
        String sql = """
            SELECT d.idDetallePedido, d.idPedido, d.idProducto, d.cantidad,
                   d.precioUnitario, d.precioTotal, pr.descripcion
            FROM detalle_pedido d
            INNER JOIN producto pr
                ON d.idProducto = pr.idProducto
            WHERE d.idPedido = ?
            ORDER BY d.idDetallePedido
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idPedido);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    DetallePedido detalle = new DetallePedido();
                    detalle.setIdDetallePedido(resultado.getInt("idDetallePedido"));
                    detalle.setIdPedido(resultado.getInt("idPedido"));
                    detalle.setIdProducto(resultado.getInt("idProducto"));
                    detalle.setCantidad(resultado.getInt("cantidad"));
                    detalle.setPrecioUnitario(resultado.getBigDecimal("precioUnitario"));
                    detalle.setPrecioTotal(resultado.getBigDecimal("precioTotal"));
                    detalle.setDescripcionProducto(resultado.getString("descripcion"));
                    detalles.add(detalle);
                }
            }
        }
        return detalles;
    }
}