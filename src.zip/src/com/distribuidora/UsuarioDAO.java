package com.distribuidora;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    // Buscadores
    public Usuario buscarPorUsername(String username) throws SQLException {
        String sql = """
                SELECT idUsuario, username, contraseña,
                       nombreUsuario, apellidoUsuario,
                       idRolUsuario, usuarioActivo
                FROM usuario
                WHERE username = ?
                """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, username);
            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setIdUsuario(resultado.getInt("idUsuario"));
                    usuario.setUsername(resultado.getString("username"));
                    usuario.setContraseña(resultado.getString("contraseña"));
                    usuario.setNombreUsuario(resultado.getString("nombreUsuario"));
                    usuario.setApellidoUsuario(resultado.getString("apellidoUsuario"));
                    usuario.setIdRolUsuario(resultado.getInt("idRolUsuario"));
                    usuario.setUsuarioActivo(resultado.getBoolean("usuarioActivo"));
                    return usuario;
                }
                return null;
            }
        }
    }
    public String buscarNombreRol(int idRolUsuario) throws SQLException {
        String sql = """
        SELECT nombreRol
        FROM roles_usuario
        WHERE idRolUsuario = ?
        """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idRolUsuario);
            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {
                    return resultado.getString("nombreRol");
                }
                return null;
            }
        }
    }

    // Registrar un usuario nuevo
    public int insertar(Usuario usuario) throws SQLException {
        String sql = """
        INSERT INTO usuario (
            username,
            contraseña,
            nombreUsuario,
            apellidoUsuario,
            idRolUsuario,
            usuarioActivo
        ) VALUES (?, ?, ?, ?, ?, ?)
        """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, usuario.getUsername());
            sentencia.setString(2, usuario.getContraseña());
            sentencia.setString(3, usuario.getNombreUsuario());
            sentencia.setString(4, usuario.getApellidoUsuario());
            sentencia.setInt(5, usuario.getIdRolUsuario());
            sentencia.setBoolean(6, usuario.isUsuarioActivo());
            return sentencia.executeUpdate();
        }
    }

    //Elimina un usuario existente
    public int eliminar(int idUsuario) throws SQLException {
        String sql = "DELETE FROM usuario WHERE idUsuario = ?";
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idUsuario);
            return sentencia.executeUpdate();
        }
    }

    //Actualiza un usuario existente
    public int actualizar(Usuario usuario) throws SQLException {
        String sql = """
            UPDATE usuario
            SET username = ?,
                nombreUsuario = ?,
                apellidoUsuario = ?,
                idRolUsuario = ?,
                usuarioActivo = ?
            WHERE idUsuario = ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, usuario.getUsername());
            sentencia.setString(2, usuario.getNombreUsuario());
            sentencia.setString(3, usuario.getApellidoUsuario());
            sentencia.setInt(4, usuario.getIdRolUsuario());
            sentencia.setBoolean(5, usuario.isUsuarioActivo());
            sentencia.setInt(6, usuario.getIdUsuario());

            return sentencia.executeUpdate();
        }
    }

    // Pide a la base de datos los roles existentes
    public List<RolUsuario> listarRoles() throws SQLException {
        List<RolUsuario> roles = new ArrayList<>();
        String sql = """
        SELECT idRolUsuario, nombreRol
        FROM roles_usuario
        ORDER BY idRolUsuario
        """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {
            while (resultado.next()) {
                RolUsuario rol = new RolUsuario(
                        resultado.getInt("idRolUsuario"),
                        resultado.getString("nombreRol")
                );
                roles.add(rol);
            }
        }
        return roles;
    }

    // Pide a la base de datos los usuarios para la paginación de las tablas, respetando filtros
    public List<Usuario> listarPagina(
            int limite, int offset, String filtro) throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = """
            SELECT u.idUsuario, u.username, u.nombreUsuario,
                   u.apellidoUsuario, u.idRolUsuario,
                   u.usuarioActivo, r.nombreRol
            FROM usuario u
            INNER JOIN roles_usuario r
                ON u.idRolUsuario = r.idRolUsuario
            WHERE (? = ''
                   OR CAST(u.idUsuario AS CHAR) LIKE ?
                   OR u.username LIKE ?
                   OR u.nombreUsuario LIKE ?
                   OR u.apellidoUsuario LIKE ?)
            ORDER BY u.idUsuario
            LIMIT ? OFFSET ?
            """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            sentencia.setString(1, busqueda);
            sentencia.setString(2, "%" + busqueda + "%");
            sentencia.setString(3, "%" + busqueda + "%");
            sentencia.setString(4, "%" + busqueda + "%");
            sentencia.setString(5, "%" + busqueda + "%");
            sentencia.setInt(6, limite);
            sentencia.setInt(7, offset);
            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setIdUsuario(resultado.getInt("idUsuario"));
                    usuario.setUsername(resultado.getString("username"));
                    usuario.setNombreUsuario(resultado.getString("nombreUsuario"));
                    usuario.setApellidoUsuario(resultado.getString("apellidoUsuario"));
                    usuario.setIdRolUsuario(resultado.getInt("idRolUsuario"));
                    usuario.setUsuarioActivo(resultado.getBoolean("usuarioActivo"));
                    usuario.setNombreRol(resultado.getString("nombreRol"));
                    usuarios.add(usuario);
                }
            }
        }
        return usuarios;
    }

    // Calcula cuantos usuarios hay para determinar la cantidad de páginas
    public int contarUsuarios(String filtro) throws SQLException {
        String sql = """
        SELECT COUNT(*)
        FROM usuario
        WHERE (? = ''
               OR CAST(idUsuario AS CHAR) LIKE ?
               OR username LIKE ?
               OR nombreUsuario LIKE ?
               OR apellidoUsuario LIKE ?)
        """;
        try (Connection conexion = ConexionMySQL.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            String busqueda = filtro == null ? "" : filtro.trim();
            sentencia.setString(1, busqueda);
            sentencia.setString(2, "%" + busqueda + "%");
            sentencia.setString(3, "%" + busqueda + "%");
            sentencia.setString(4, "%" + busqueda + "%");
            sentencia.setString(5, "%" + busqueda + "%");
            try (ResultSet resultado = sentencia.executeQuery()) {
                resultado.next();
                return resultado.getInt(1);
            }
        }
    }
}
