package com.distribuidora;

import java.util.List;
import java.io.IOException;
import java.sql.SQLException;

import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class UsuarioController {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private Usuario usuarioSeleccionado;

    // fx:id de la vista principal de usuarios
    @FXML private TextField buscarUsuarioUsuariosField;
    @FXML private TableView<Usuario> usuariosTable;
    @FXML private TableColumn<Usuario, Integer> codigoColumn;
    @FXML private TableColumn<Usuario, String> usernameColumn;
    @FXML private TableColumn<Usuario, String> nombreColumn;
    @FXML private TableColumn<Usuario, String> apellidoColumn;
    @FXML private TableColumn<Usuario, String> rolColumn;
    @FXML private TableColumn<Usuario, String> estadoColumn;
    @FXML private TableColumn<Usuario, Object> accionesColumn;
    @FXML private Pagination paginacionUsuarios;
    private static final int USUARIOS_POR_PAGINA = 10;

    // fx:id de las vistas del usuario
    @FXML private TextField idUsuarioField;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField nombreUsuarioField;
    @FXML private TextField apellidoUsuarioField;
    @FXML private CheckBox usuarioActivoCheckBox;
    @FXML private ComboBox<RolUsuario> rolUsuarioComboBox;
    @FXML private Label usernameLabel;
    @FXML private Label rolUsuarioLabel;
    @FXML private Label estadoUsuarioLabel;


    // Mensaje emergente
    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    // Metodo que se ejecuta al abrir/refrescar la vista (Archivo FXML)
    @FXML public void initialize() {
        if (usuariosTable == null) {
            if (rolUsuarioComboBox != null) {
                cargarRoles();
            }
            return;
        }
        codigoColumn.setCellValueFactory(new PropertyValueFactory<>("idUsuario"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombreUsuario"));
        apellidoColumn.setCellValueFactory(new PropertyValueFactory<>("apellidoUsuario"));
        rolColumn.setCellValueFactory(new PropertyValueFactory<>("nombreRol"));
        estadoColumn.setCellValueFactory(
                celda -> new javafx.beans.property.SimpleStringProperty(
                        celda.getValue().isUsuarioActivo() ? "Activo" : "No activo")
        );
        paginacionUsuarios.currentPageIndexProperty().addListener(
                (observable, paginaAnterior, paginaNueva) ->
                        mostrarPaginaUsuarios(paginaNueva.intValue())
        );
        configurarColumnaAcciones();
        actualizarPaginacionUsuarios();
    }

    // Creacion del usuario que se haya seleccionado en la columna Acciones
    public void setUsuarioSeleccionado(Usuario usuario) {
        this.usuarioSeleccionado = usuario;
        cargarDatosUsuario();
    }
    private void cargarDatosUsuario() {
        if (usuarioSeleccionado == null) {
            return;
        }
        if (idUsuarioField != null) {
            idUsuarioField.setText(String.valueOf(usuarioSeleccionado.getIdUsuario()));
        }
        if (usernameField != null) {
            usernameField.setText(usuarioSeleccionado.getUsername());
        }
        if (usernameLabel != null) {
            usernameLabel.setText(usuarioSeleccionado.getUsername());
        }
        if (nombreUsuarioField != null) {
            nombreUsuarioField.setText(usuarioSeleccionado.getNombreUsuario());
        }
        if (apellidoUsuarioField != null) {
            apellidoUsuarioField.setText(usuarioSeleccionado.getApellidoUsuario());
        }
        if (usuarioActivoCheckBox != null) {
            usuarioActivoCheckBox.setSelected(usuarioSeleccionado.isUsuarioActivo());
        }
        if (rolUsuarioComboBox != null) {
            RolUsuario rolSeleccionado = rolUsuarioComboBox.getItems().stream().filter(rol ->
                            rol.getIdRolUsuario() == usuarioSeleccionado.getIdRolUsuario()
                    ).findFirst().orElse(null);
            rolUsuarioComboBox.setValue(rolSeleccionado);
        }
        if (rolUsuarioLabel != null) {
            try {
                String nombreRol = usuarioDAO.buscarNombreRol(usuarioSeleccionado.getIdRolUsuario());
                rolUsuarioLabel.setText(nombreRol != null ? nombreRol : "Sin rol");
            } catch (SQLException e) {
                e.printStackTrace();
                rolUsuarioLabel.setText("No disponible");
            }
        }
        if (estadoUsuarioLabel != null) {
            estadoUsuarioLabel.setText(usuarioSeleccionado.isUsuarioActivo() ? "Activo" : "Inactivo");
        }
    }
    private void cargarRoles() {
        try {
            rolUsuarioComboBox.setItems(FXCollections.observableArrayList(usuarioDAO.listarRoles()));
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron cargar los roles de usuario.");
        }
    }

    // Acciones de la vista principal
    private void abrirVistaUsuario(String nombreVista, Usuario usuario) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(nombreVista));
            Parent vista = loader.load();
            UsuarioController controller = loader.getController();
            controller.setUsuarioSeleccionado(usuario);
            Stage ventana = new Stage();
            ventana.setTitle("Gestión de usuario");
            ventana.setScene(new Scene(vista));
            ventana.initModality(Modality.APPLICATION_MODAL);
            ventana.setResizable(false);
            ventana.showAndWait();
            actualizarPaginacionUsuarios();
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo abrir la vista de usuario.");
        }
    }
    @FXML private void volverAlInicio() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/menu-view.fxml"));
            Stage ventana = (Stage) usuariosTable.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo volver a la pantalla principal.");
        }
    }
    @FXML private void nuevoUsuario() {
        abrirVistaUsuario("/resources/com/distribuidora/registrar-usuario-view.fxml", null);
    }
    @FXML private void registrarUsuario() {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        String username = usernameField.getText().trim();
        String contraseña = passwordField.getText();
        String nombre = nombreUsuarioField.getText().trim();
        String apellido = apellidoUsuarioField.getText().trim();
        RolUsuario rolSeleccionado = rolUsuarioComboBox.getValue();
        boolean usuarioActivo = usuarioActivoCheckBox.isSelected();
        if (username.isEmpty() ||
                contraseña.isEmpty() ||
                nombre.isEmpty() ||
                apellido.isEmpty() ||
                rolSeleccionado == null) {
            mostrarMensaje("Validación", "Completá todos los campos obligatorios.");
            return;
        }
        try {
            Usuario usuarioEncontrado = usuarioDAO.buscarPorUsername(username);
            if (usuarioEncontrado != null) {
                mostrarMensaje("Validación", "El nombre de usuario ya existe.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo comprobar el nombre de usuario.");
            return;
        }
        if (username.length() < 4 || username.length() > 20) {
            mostrarMensaje("Validación",
                    "El nombre de usuario debe tener 6 caracteres como mínimo y 20 como máximo");
            return;
        }
        if (contraseña.length() < 6) {
            mostrarMensaje("Validación", "La contraseña debe tener minimo 6 caracteres");
            return;
        }
        Usuario usuario = new Usuario(
                0,
                username,
                contraseña,
                nombre,
                apellido,
                rolSeleccionado.getIdRolUsuario(),
                usuarioActivo
        );
        try {
            int filasAfectadas = usuarioDAO.insertar(usuario);
            if (filasAfectadas == 1) {
                mostrarMensaje("Registro exitoso", "El usuario se registró correctamente.");
                Stage ventana = (Stage) usernameField
                        .getScene().getWindow();
                ventana.close();
            } else {
                mostrarMensaje("Registro", "No se pudo registrar el usuario.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "Ocurrió un error al registrar el usuario.");
        }
    }
    @FXML private void eliminarUsuario() {
        if (usuarioSeleccionado == null) {
            mostrarMensaje("Error", "No se seleccionó ningún usuario.");
            return;
        }
        try {
            int filasAfectadas = usuarioDAO.eliminar(usuarioSeleccionado.getIdUsuario());
            if (filasAfectadas == 0) {
                mostrarMensaje("Información", "El usuario seleccionado no existe.");
                return;
            }
            actualizarPaginacionUsuarios();
            mostrarMensaje("Éxito", "Usuario eliminado correctamente.");
            cerrarVentana();
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudo eliminar el usuario. Puede estar " + "asociado a otros registros.");
        }
    }
    @FXML private void modificarUsuario() {
        if (usuarioSeleccionado == null) {
            mostrarMensaje("Error", "No se seleccionó ningún usuario.");
            return;
        }
        String username = usernameField.getText().trim();
        String nombre = nombreUsuarioField.getText().trim();
        String apellido = apellidoUsuarioField.getText().trim();
        RolUsuario rolSeleccionado = rolUsuarioComboBox.getValue();
        if (username.isEmpty() ||
                nombre.isEmpty() ||
                apellido.isEmpty() ||
                rolSeleccionado == null) {
            mostrarMensaje("Error", "Completá todos los campos obligatorios.");
            return;
        }
        if (username.length() < 4 || username.length() > 20) {
            mostrarMensaje("Validación",
                    "El nombre de usuario debe tener 6 caracteres como mínimo y 20 como máximo");
            return;
        }
        try {
            Usuario usuarioEncontrado = usuarioDAO.buscarPorUsername(username);
            if (usuarioEncontrado != null && usuarioEncontrado.getIdUsuario() != usuarioSeleccionado.getIdUsuario()) {
                mostrarMensaje("Validación", "El nombre de usuario ya existe.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo comprobar el nombre de usuario.");
            return;
        }
        Usuario usuarioActualizado = new Usuario();
        usuarioActualizado.setIdUsuario(usuarioSeleccionado.getIdUsuario());
        usuarioActualizado.setUsername(username);
        usuarioActualizado.setNombreUsuario(nombre);
        usuarioActualizado.setApellidoUsuario(apellido);
        usuarioActualizado.setIdRolUsuario(rolSeleccionado.getIdRolUsuario());
        usuarioActualizado.setUsuarioActivo(usuarioActivoCheckBox.isSelected());
        try {
            int filasAfectadas = usuarioDAO.actualizar(usuarioActualizado);
            if (filasAfectadas == 0) {
                mostrarMensaje("Información",
                        "No se modificaron filas. Verificá que "
                                + "el usuario exista y que los datos hayan cambiado.");
                return;
            }
            actualizarPaginacionUsuarios();
            mostrarMensaje("Éxito",
                    "Usuario actualizado correctamente.");
            cerrarVentana();
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudieron guardar los cambios. "
                            + "Verificá que el nombre de usuario no esté repetido.");
        }
    }

    private void cerrarVentana() {
        if (usernameField != null && usernameField.getScene() != null) {
            Stage ventana = (Stage) usernameField.getScene().getWindow();
            ventana.close();
        } else if (usernameLabel != null && usernameLabel.getScene() != null) {
            Stage ventana = (Stage) usernameLabel.getScene().getWindow();
            ventana.close();
        }
    }
    @FXML private void cancelar() {
        cerrarVentana();
    }

    private void configurarColumnaAcciones() {
        accionesColumn.setCellFactory(columna -> new TableCell<>() {
            private final Button accionesButton = new Button("⋮"); {
                accionesButton.setOnAction(event -> {
                    Usuario usuario = getTableView()
                            .getItems()
                            .get(getIndex());
                    ContextMenu menu = new ContextMenu();
                    MenuItem verItem = new MenuItem("Ver");
                    MenuItem editarItem = new MenuItem("Editar");
                    MenuItem eliminarItem = new MenuItem("Eliminar");
                    verItem.setOnAction(e ->
                            abrirVistaUsuario("/resources/com/distribuidora/ver-usuario-view.fxml", usuario)
                    );
                    editarItem.setOnAction(e ->
                            abrirVistaUsuario("/resources/com/distribuidora/editar-usuario-view.fxml", usuario)
                    );
                    eliminarItem.setOnAction(e ->
                            abrirVistaUsuario("/resources/com/distribuidora/eliminar-usuario-view.fxml", usuario)
                    );
                    menu.getItems().addAll(
                            verItem,
                            editarItem,
                            eliminarItem
                    );
                    menu.show(accionesButton, javafx.geometry.Side.BOTTOM, 0, 0);
                });
            }
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : accionesButton);
            }
        });
    }

    private void actualizarPaginacionUsuarios() {
        if (usuariosTable == null || paginacionUsuarios == null) {
            return;
        }
        try {
            String filtro = buscarUsuarioUsuariosField == null
                    ? "" : buscarUsuarioUsuariosField.getText().trim();
            int cantidadUsuarios = usuarioDAO.contarUsuarios(filtro);
            int cantidadPaginas = (int) Math.ceil((double) cantidadUsuarios / USUARIOS_POR_PAGINA);
            cantidadPaginas = Math.max(1, cantidadPaginas);
            paginacionUsuarios.setPageCount(cantidadPaginas);
            int paginaActual = Math.min(paginacionUsuarios.getCurrentPageIndex(), cantidadPaginas - 1);
            if (paginacionUsuarios.getCurrentPageIndex() != paginaActual) {
                paginacionUsuarios.setCurrentPageIndex(paginaActual);
            } else {
                mostrarPaginaUsuarios(paginaActual);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la lista de usuarios.");
        }
    }
    private void mostrarPaginaUsuarios(int indicePagina) {
        try {
            String filtro = buscarUsuarioUsuariosField.getText();
            int offset = indicePagina * USUARIOS_POR_PAGINA;
            List<Usuario> usuarios = usuarioDAO.listarPagina(USUARIOS_POR_PAGINA, offset, filtro);
            usuariosTable.getItems().setAll(usuarios);
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron mostrar los usuarios.");
        }
    }
    @FXML private void filtrarUsuarios() {
        paginacionUsuarios.setCurrentPageIndex(0);
        actualizarPaginacionUsuarios();
    }
}

