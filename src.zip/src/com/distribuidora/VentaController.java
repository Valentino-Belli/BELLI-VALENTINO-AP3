package com.distribuidora;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class VentaController {

    private final VentaDAO ventaDAO = new VentaDAO();
    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final ProductoDAO productoDAO = new ProductoDAO();
    private Venta ventaSeleccionada;

    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    // Máximo que entra en un DECIMAL(10,2)
    private static final BigDecimal IMPORTE_MAXIMO = new BigDecimal("99999999.99");
    // Cantidad máxima de resultados que se cargan en el ComboBox en cada búsqueda
    private static final int LIMITE_COMBOBOX = 100;

    // fx:id de la vista principal de ventas
    @FXML private TextField buscarVentaVentasField;
    @FXML private TableView<Venta> ventasTable;
    @FXML private TableColumn<Venta, Integer> codigoColumn;
    @FXML private TableColumn<Venta, String> fechaColumn;
    @FXML private TableColumn<Venta, String> clienteColumn;
    @FXML private TableColumn<Venta, String> dniColumn;
    @FXML private TableColumn<Venta, String> estadoColumn;
    @FXML private TableColumn<Venta, String> usuarioColumn;
    @FXML private TableColumn<Venta, Object> accionesColumn;
    @FXML private Pagination paginacionVentas;
    private static final int VENTAS_POR_PAGINA = 10;

    // fx:id de las vistas de la venta (registrar, ver y anular)
    @FXML private Label idVentaLabel;
    @FXML private Label fechaVentaLabel;
    @FXML private Label clienteVentaLabel;
    @FXML private Label dniClienteLabel;
    @FXML private Label usuarioVentaLabel;
    @FXML private Label estadoVentaLabel;
    @FXML private Label totalLabel;
    @FXML private TextField buscarClienteField;
    @FXML private ComboBox<Cliente> clienteComboBox;
    @FXML private ComboBox<EstadoVenta> estadoVentaComboBox;
    @FXML private TextField buscarProductoField;
    @FXML private ComboBox<Producto> productoComboBox;
    @FXML private Label precioUnitarioLabel;
    @FXML private TextField cantidadField;
    @FXML private TableView<DetalleVenta> detalleTable;
    @FXML private TableColumn<DetalleVenta, String> detalleProductoColumn;
    @FXML private TableColumn<DetalleVenta, Integer> detalleCantidadColumn;
    @FXML private TableColumn<DetalleVenta, BigDecimal> detallePrecioUnitarioColumn;
    @FXML private TableColumn<DetalleVenta, BigDecimal> detalleSubtotalColumn;


    // Mensaje emergente
    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    // Da formato a un importe para mostrarlo en pantalla
    private String formatearImporte(BigDecimal importe) {
        return "$ " + importe.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    private boolean esNombreAnulado(String nombreEstado) {
        if (nombreEstado == null) {
            return false;
        }
        String nombre = nombreEstado.trim().toLowerCase();
        return nombre.startsWith("anulad") || nombre.startsWith("cancelad");
    }
    private boolean esNombrePendiente(String nombreEstado) {
        return nombreEstado != null && nombreEstado.trim().toLowerCase().startsWith("pendient");
    }
    private boolean esNombreConfirmado(String nombreEstado) {
        return nombreEstado != null && nombreEstado.trim().toLowerCase().startsWith("confirmad");
    }

    // Metodo que se ejecuta al abrir/refrescar la vista (Archivo FXML)
    @FXML private void initialize() {
        if (ventasTable != null) {
            ventasTable.setItems(FXCollections.observableArrayList());
            codigoColumn.setCellValueFactory(new PropertyValueFactory<>("idVenta"));
            fechaColumn.setCellValueFactory(celda ->
                    new ReadOnlyStringWrapper(celda.getValue().getFecha().format(FORMATO_FECHA)));
            clienteColumn.setCellValueFactory(new PropertyValueFactory<>("nombreCliente"));
            dniColumn.setCellValueFactory(new PropertyValueFactory<>("dniCliente"));
            estadoColumn.setCellValueFactory(new PropertyValueFactory<>("nombreEstado"));
            usuarioColumn.setCellValueFactory(new PropertyValueFactory<>("nombreUsuario"));
            configurarColumnaAcciones();
            if (paginacionVentas != null) {
                paginacionVentas.currentPageIndexProperty().addListener(
                        (observable, anterior, nuevo) ->
                                mostrarPaginaVentas(nuevo.intValue())
                );
            }
        }
        if (detalleTable != null) {
            configurarTablaDetalle();
        }
        if (estadoVentaComboBox != null) {
            cargarEstados();
        }
        if (clienteComboBox != null) {
            configurarComboBoxCliente();
            cargarClientes("");
        }
        if (productoComboBox != null) {
            configurarComboBoxProducto();
            cargarProductos("");
        }
        if (fechaVentaLabel != null) {
            fechaVentaLabel.setText(LocalDate.now().format(FORMATO_FECHA));
        }
        actualizarPaginacionVentas();
    }

    private void configurarTablaDetalle() {
        detalleTable.setItems(FXCollections.observableArrayList());
        detalleProductoColumn.setCellValueFactory(new PropertyValueFactory<>("descripcionProducto"));
        detalleCantidadColumn.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        detallePrecioUnitarioColumn.setCellValueFactory(new PropertyValueFactory<>("precioUnitario"));
        detalleSubtotalColumn.setCellValueFactory(new PropertyValueFactory<>("precioTotal"));
    }
    private void cargarEstados() {
        try {
            // Solo se pueden dar de alta ventas Pendientes o Confirmadas
            estadoVentaComboBox.setItems(FXCollections.observableArrayList(
                    ventaDAO.listarEstados().stream()
                            .filter(estado -> esNombrePendiente(estado.getNombreEstado())
                                    || esNombreConfirmado(estado.getNombreEstado()))
                            .toList()));
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron cargar los estados de venta.");
        }
    }
    private void configurarComboBoxProducto() {
        productoComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(Producto producto) {
                return producto == null ? "" : producto.getIdProducto() + " - "
                        + producto.getDescripcion() + " (stock: " + producto.getStockActual() + ")";
            }
            @Override
            public Producto fromString(String texto) {
                return null;
            }
        });
        // Al elegir un producto se muestra su precio de venta
        productoComboBox.valueProperty().addListener((observable, anterior, nuevo) -> {
            if (precioUnitarioLabel != null) {
                precioUnitarioLabel.setText(nuevo == null ? "-"
                        : formatearImporte(precioDeVenta(nuevo)));
            }
        });
    }
    // Rearma el ComboBox con los productos que coinciden con el filtro (código o descripción)
    private void cargarProductos(String filtro) {
        try {
            List<Producto> productos = productoDAO.listarPaginaProducto(LIMITE_COMBOBOX, 0, filtro);
            productoComboBox.setValue(null);
            productoComboBox.setItems(FXCollections.observableArrayList(productos));
            if (productos.isEmpty() && !filtro.isBlank()) {
                mostrarMensaje("Información", "No se encontraron productos con ese criterio.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron cargar los productos.");
        }
    }
    @FXML private void buscarProductos() {
        cargarProductos(buscarProductoField.getText().trim());
        if (!productoComboBox.getItems().isEmpty()) {
            productoComboBox.show();
        }
    }
    // Convierte el precio float del producto a BigDecimal sin decimales raros
    private BigDecimal precioDeVenta(Producto producto) {
        return new BigDecimal(Float.toString(producto.getPrecio())).setScale(2, RoundingMode.HALF_UP);
    }

    // Creacion de la venta que se haya seleccionado en la columna Acciones
    public void setVentaSeleccionada(Venta venta) {
        this.ventaSeleccionada = venta;
        cargarDatosVenta();
    }
    private void cargarDatosVenta() {
        if (ventaSeleccionada == null) {
            return;
        }
        if (idVentaLabel != null) {
            idVentaLabel.setText(String.valueOf(ventaSeleccionada.getIdVenta()));
        }
        if (fechaVentaLabel != null) {
            fechaVentaLabel.setText(ventaSeleccionada.getFecha().format(FORMATO_FECHA));
        }
        if (clienteVentaLabel != null) {
            clienteVentaLabel.setText(ventaSeleccionada.getNombreCliente());
        }
        if (dniClienteLabel != null) {
            dniClienteLabel.setText(ventaSeleccionada.getDniCliente());
        }
        if (usuarioVentaLabel != null) {
            usuarioVentaLabel.setText(ventaSeleccionada.getNombreUsuario());
        }
        if (estadoVentaLabel != null) {
            estadoVentaLabel.setText(ventaSeleccionada.getNombreEstado());
        }
        if (detalleTable != null) {
            try {
                List<DetalleVenta> detalles = ventaDAO.listarDetalles(ventaSeleccionada.getIdVenta());
                ventaSeleccionada.setDetalles(detalles);
                detalleTable.getItems().setAll(detalles);
                actualizarTotal();
            } catch (SQLException e) {
                e.printStackTrace();
                mostrarMensaje("Error", "No se pudieron cargar los productos de la venta.");
            }
        }
    }

    // Acciones de la vista principal
    private void abrirVistaVenta(String nombreVista, Venta venta) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(nombreVista));
            Parent vista = loader.load();
            VentaController controller = loader.getController();
            controller.setVentaSeleccionada(venta);
            Stage ventana = new Stage();
            ventana.setTitle("Gestión de venta");
            ventana.setScene(new Scene(vista));
            ventana.initModality(Modality.APPLICATION_MODAL);
            ventana.setResizable(false);
            ventana.showAndWait();
            actualizarPaginacionVentas();
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo abrir la vista de la venta.");
        }
    }
    @FXML private void volverAlInicio() {
        try {
            Parent vista = FXMLLoader.load(getClass().getResource("/resources/com/distribuidora/menu-view.fxml"));
            Stage ventana = (Stage) ventasTable.getScene().getWindow();
            ventana.setScene(new Scene(vista));
            ventana.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo volver a la pantalla principal.");
        }
    }
    @FXML private void nuevaVenta() {
        abrirVistaVenta("/resources/com/distribuidora/registrar-venta-view.fxml", null);
    }

    private void configurarComboBoxCliente() {
        clienteComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(Cliente cliente) {
                return cliente == null ? "" : cliente.getNombreCliente() + " "
                        + cliente.getApellidoCliente() + " - DNI " + cliente.getDni();
            }
            @Override
            public Cliente fromString(String texto) {
                return null;
            }
        });
    }
    // Rearma el ComboBox con los clientes que coinciden con el filtro (DNI, nombre o apellido)
    private void cargarClientes(String filtro) {
        try {
            List<Cliente> clientes = clienteDAO.buscarPorDniONombre(filtro, LIMITE_COMBOBOX);
            clienteComboBox.setValue(null);
            clienteComboBox.setItems(FXCollections.observableArrayList(clientes));
            if (clientes.isEmpty() && !filtro.isBlank()) {
                mostrarMensaje("Información", "No se encontraron clientes con ese criterio.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron cargar los clientes.");
        }
    }
    @FXML private void buscarClientes() {
        cargarClientes(buscarClienteField.getText().trim());
        if (!clienteComboBox.getItems().isEmpty()) {
            clienteComboBox.show();
        }
    }

    // Agrega un producto a la lista de la venta (todavía no se guarda en la base de datos)
    @FXML private void agregarProducto() {
        Producto producto = productoComboBox.getValue();
        if (producto == null) {
            mostrarMensaje("Validación", "Seleccioná un producto.");
            return;
        }
        try {
            int cantidad = Integer.parseInt(cantidadField.getText().trim());
            if (cantidad <= 0) {
                mostrarMensaje("Validación", "La cantidad debe ser mayor que 0.");
                return;
            }
            BigDecimal precio = precioDeVenta(producto);
            if (precio.compareTo(BigDecimal.ZERO) <= 0) {
                mostrarMensaje("Validación", "El producto " + producto.getDescripcion()
                        + " tiene precio 0. Actualizá su precio en Productos antes de venderlo.");
                return;
            }
            for (DetalleVenta existente : detalleTable.getItems()) {
                if (existente.getIdProducto() == producto.getIdProducto()) {
                    mostrarMensaje("Validación",
                            "El producto ya está en la venta. Quitalo y volvé a agregarlo con la cantidad correcta.");
                    return;
                }
            }
            if (cantidad > producto.getStockActual()) {
                mostrarMensaje("Validación",
                        "No hay suficiente stock de " + producto.getDescripcion()
                                + ". Stock actual: " + producto.getStockActual() + ".");
                return;
            }
            DetalleVenta detalle = new DetalleVenta(producto.getIdProducto(), cantidad, precio);
            if (detalle.getPrecioTotal().compareTo(IMPORTE_MAXIMO) > 0) {
                mostrarMensaje("Validación", "El importe del producto es demasiado grande.");
                return;
            }
            detalle.setDescripcionProducto(producto.getDescripcion());
            detalleTable.getItems().add(detalle);
            actualizarTotal();
            productoComboBox.setValue(null);
            cantidadField.clear();
        } catch (NumberFormatException e) {
            mostrarMensaje("Validación", "La cantidad debe ser un número entero.");
        }
    }
    @FXML private void quitarProducto() {
        DetalleVenta seleccionado = detalleTable.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarMensaje("Información", "Seleccioná un producto de la tabla para quitarlo.");
            return;
        }
        detalleTable.getItems().remove(seleccionado);
        actualizarTotal();
    }
    private void actualizarTotal() {
        if (totalLabel == null || detalleTable == null) {
            return;
        }
        BigDecimal total = BigDecimal.ZERO;
        for (DetalleVenta detalle : detalleTable.getItems()) {
            total = total.add(detalle.getPrecioTotal());
        }
        totalLabel.setText(formatearImporte(total));
    }

    @FXML private void registrarVenta() {
        Usuario usuario = Sesion.getUsuarioActual();
        if (usuario == null) {
            mostrarMensaje("Error", "No hay un usuario con sesión iniciada.");
            return;
        }
        Cliente cliente = clienteComboBox.getValue();
        if (cliente == null) {
            mostrarMensaje("Validación", "Buscá y seleccioná un cliente.");
            return;
        }
        EstadoVenta estado = estadoVentaComboBox.getValue();
        if (estado == null) {
            mostrarMensaje("Validación", "Seleccioná el estado de la venta.");
            return;
        }
        if (!esNombrePendiente(estado.getNombreEstado())
                && !esNombreConfirmado(estado.getNombreEstado())) {
            mostrarMensaje("Validación", "Solo se puede registrar una venta Pendiente o Confirmada.");
            return;
        }
        if (detalleTable.getItems().isEmpty()) {
            mostrarMensaje("Validación", "Agregá al menos un producto a la venta.");
            return;
        }
        Venta venta = new Venta(0, LocalDate.now(), estado.getIdEstadoVenta(),
                usuario.getIdUsuario(), cliente.getIdCliente());
        venta.setDetalles(new ArrayList<>(detalleTable.getItems()));
        try {
            int idVenta = ventaDAO.registrarVenta(venta);
            mostrarMensaje("Registro exitoso",
                    "La venta N° " + idVenta + " se registró correctamente y el stock fue actualizado.");
            cerrarVentana();
        } catch (SQLException e) {
            e.printStackTrace();
            if (e.getMessage() != null && e.getMessage().startsWith("Stock insuficiente")) {
                mostrarMensaje("Stock insuficiente", e.getMessage());
            } else {
                mostrarMensaje("Error de base de datos",
                        "No se pudo registrar la venta. No se realizó ningún cambio.");
            }
        }
    }
    @FXML private void confirmarVenta() {
        if (ventaSeleccionada == null) {
            mostrarMensaje("Error", "No se seleccionó ninguna venta.");
            return;
        }
        try {
            EstadoVenta estadoPendiente = null;
            EstadoVenta estadoConfirmado = null;
            for (EstadoVenta estado : ventaDAO.listarEstados()) {
                if (esNombrePendiente(estado.getNombreEstado())) {
                    estadoPendiente = estado;
                } else if (esNombreConfirmado(estado.getNombreEstado())) {
                    estadoConfirmado = estado;
                }
            }
            if (estadoPendiente == null || estadoConfirmado == null) {
                mostrarMensaje("Error",
                        "No existen los estados \"Pendiente\" y \"Confirmada\" en la tabla estado_venta.");
                return;
            }
            int filasAfectadas = ventaDAO.confirmarVenta(ventaSeleccionada.getIdVenta(),
                    estadoPendiente.getIdEstadoVenta(), estadoConfirmado.getIdEstadoVenta());
            if (filasAfectadas == 0) {
                mostrarMensaje("Información", "La venta no existe o ya no está pendiente.");
                return;
            }
            mostrarMensaje("Éxito", "Venta confirmada correctamente.");
            cerrarVentana();
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudo confirmar la venta. No se realizó ningún cambio.");
        }
    }
    @FXML private void anularVenta() {
        if (ventaSeleccionada == null) {
            mostrarMensaje("Error", "No se seleccionó ninguna venta.");
            return;
        }
        try {
            EstadoVenta estadoPendiente = null;
            EstadoVenta estadoAnulado = null;
            for (EstadoVenta estado : ventaDAO.listarEstados()) {
                if (esNombrePendiente(estado.getNombreEstado())) {
                    estadoPendiente = estado;
                } else if (esNombreAnulado(estado.getNombreEstado())) {
                    estadoAnulado = estado;
                }
            }
            if (estadoPendiente == null || estadoAnulado == null) {
                mostrarMensaje("Error",
                        "No existen los estados \"Pendiente\" y \"Anulada\" (o \"Cancelada\") en la tabla estado_venta.");
                return;
            }
            int filasAfectadas = ventaDAO.anularVenta(ventaSeleccionada.getIdVenta(),
                    estadoPendiente.getIdEstadoVenta(), estadoAnulado.getIdEstadoVenta());
            if (filasAfectadas == 0) {
                mostrarMensaje("Información",
                        "La venta no existe o ya no está pendiente. Solo se pueden anular ventas pendientes.");
                return;
            }
            mostrarMensaje("Éxito", "Venta anulada correctamente. El stock fue devuelto.");
            cerrarVentana();
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos",
                    "No se pudo anular la venta. No se realizó ningún cambio.");
        }
    }

    private void cerrarVentana() {
        if (detalleTable != null && detalleTable.getScene() != null) {
            Stage ventana = (Stage) detalleTable.getScene().getWindow();
            ventana.close();
        }
    }
    @FXML private void cancelar() {
        cerrarVentana();
    }

    private void configurarColumnaAcciones() {
        accionesColumn.setCellFactory(columna -> new TableCell<>() {
            private final Button accionesButton = new Button("⋮"); {
                accionesButton.setOnAction(event -> {
                    Venta venta = getTableView()
                            .getItems()
                            .get(getIndex());
                    ContextMenu menu = new ContextMenu();
                    MenuItem verItem = new MenuItem("Ver");
                    MenuItem confirmarItem = new MenuItem("Confirmar");
                    MenuItem anularItem = new MenuItem("Anular");
                    verItem.setOnAction(e ->
                            abrirVistaVenta("/resources/com/distribuidora/ver-venta-view.fxml", venta)
                    );
                    confirmarItem.setOnAction(e ->
                            abrirVistaVenta("/resources/com/distribuidora/confirmar-venta-view.fxml", venta)
                    );
                    anularItem.setOnAction(e ->
                            abrirVistaVenta("/resources/com/distribuidora/anular-venta-view.fxml", venta)
                    );
                    // Pendiente: Ver, Confirmar, Anular | Confirmada y Anulada: solo Ver
                    menu.getItems().add(verItem);
                    if (esNombrePendiente(venta.getNombreEstado())) {
                        menu.getItems().addAll(confirmarItem, anularItem);
                    }
                    menu.show(accionesButton, javafx.geometry.Side.BOTTOM, 0, 0);
                });
            }
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : accionesButton);
            }
        });
    }

    private void actualizarPaginacionVentas() {
        if (ventasTable == null || paginacionVentas == null) {
            return;
        }
        try {
            String filtro = buscarVentaVentasField == null
                    ? "" : buscarVentaVentasField.getText().trim();
            int cantidadVentas = ventaDAO.contarVentas(filtro);
            int cantidadPaginas = (int) Math.ceil((double) cantidadVentas / VENTAS_POR_PAGINA);
            cantidadPaginas = Math.max(1, cantidadPaginas);
            paginacionVentas.setPageCount(cantidadPaginas);
            int paginaActual = Math.min(paginacionVentas.getCurrentPageIndex(), cantidadPaginas - 1);
            if (paginacionVentas.getCurrentPageIndex() != paginaActual) {
                paginacionVentas.setCurrentPageIndex(paginaActual);
            } else {
                mostrarPaginaVentas(paginaActual);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudo cargar la lista de ventas.");
        }
    }
    private void mostrarPaginaVentas(int indicePagina) {
        try {
            String filtro = buscarVentaVentasField == null
                    ? "" : buscarVentaVentasField.getText();
            int offset = indicePagina * VENTAS_POR_PAGINA;
            List<Venta> ventas = ventaDAO.listarPagina(VENTAS_POR_PAGINA, offset, filtro);
            ventasTable.getItems().setAll(ventas);
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error", "No se pudieron mostrar las ventas.");
        }
    }
    @FXML private void filtrarVentas() {
        paginacionVentas.setCurrentPageIndex(0);
        actualizarPaginacionVentas();
    }
}
