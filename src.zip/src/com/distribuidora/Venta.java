package com.distribuidora;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Venta {

    private int idVenta;
    private LocalDate fecha;
    private int idEstadoVenta;
    private int idUsuario;
    private int idCliente;
    // Solo para mostrar en tablas (vienen de los JOIN)
    private String nombreEstado;
    private String nombreCliente;
    private String dniCliente;
    private String nombreUsuario;
    private List<DetalleVenta> detalles;

    public Venta() {
        this.detalles = new ArrayList<>();
    }

    public Venta(int idVenta, LocalDate fecha, int idEstadoVenta,
                 int idUsuario, int idCliente) {
        this.idVenta = idVenta;
        this.fecha = fecha;
        this.idEstadoVenta = idEstadoVenta;
        this.idUsuario = idUsuario;
        this.idCliente = idCliente;
        this.detalles = new ArrayList<>();
    }

    public int getIdVenta() {
        return idVenta;
    }
    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public LocalDate getFecha() {
        return fecha;
    }
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public int getIdEstadoVenta() {
        return idEstadoVenta;
    }
    public void setIdEstadoVenta(int idEstadoVenta) {
        this.idEstadoVenta = idEstadoVenta;
    }

    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdCliente() {
        return idCliente;
    }
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombreEstado() {
        return nombreEstado;
    }
    public void setNombreEstado(String nombreEstado) {
        this.nombreEstado = nombreEstado;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }
    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getDniCliente() {
        return dniCliente;
    }
    public void setDniCliente(String dniCliente) {
        this.dniCliente = dniCliente;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public List<DetalleVenta> getDetalles() {
        return detalles;
    }
    public void setDetalles(List<DetalleVenta> detalles) {
        this.detalles = detalles;
    }

    // Suma de los precios totales de los detalles
    public BigDecimal getTotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (DetalleVenta detalle : detalles) {
            total = total.add(detalle.getPrecioTotal());
        }
        return total;
    }
}