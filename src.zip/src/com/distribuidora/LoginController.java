package com.distribuidora;

import java.io.IOException;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LoginController {

    // fx:id de la vista de login
    @FXML private TextField usuarioField;
    @FXML private PasswordField contraseñaField;

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    // Mensaje emergente
    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    @FXML private void iniciarSesion() {
        String username = usuarioField.getText().trim();
        String contraseña = contraseñaField.getText();
        if (username.isBlank() || contraseña.isBlank()) {
            mostrarMensaje("Campos incompletos",
                    "Completá el nombre de usuario y la contraseña.");
            return;
        }
        try {
            Usuario usuario = usuarioDAO.buscarPorUsername(username);
            if (usuario == null
                    || !usuario.getContraseña().equals(contraseña)
                    || !usuario.isUsuarioActivo()) {
                mostrarMensaje("Error de inicio de sesión",
                        "Usuario o contraseña incorrectos, o cuenta inactiva.");
                return;
            }
            try {
                Sesion.setUsuarioActual(usuario);
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/com/distribuidora/menu-view.fxml"));
                Parent vista = loader.load();
                MenuController menuController = loader.getController();
                menuController.setUsuario(usuario);
                Stage ventana = (Stage) usuarioField.getScene().getWindow();
                ventana.setScene(new Scene(vista));
                ventana.setTitle("Menú principal");
            } catch (IOException e) {
                e.printStackTrace();
                mostrarMensaje("Error", "No se pudo abrir el menú principal.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarMensaje("Error de base de datos", "No se pudo validar el inicio de sesión.");
        }
    }
}

