package com.distribuidora;

import java.time.LocalDateTime;

public class MovimientoStock {

    private Producto producto;
    private String tipo;
    private int cantidad;
    private LocalDateTime fechaHora;

    public MovimientoStock(Producto producto, String tipo, int cantidad) {
        this.producto = producto;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.fechaHora = LocalDateTime.now();
    }

    public MovimientoStock(Producto producto, String tipo, int cantidad, LocalDateTime fechaHora) {
        this.producto = producto;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.fechaHora = fechaHora;
    }

    public Producto getProducto() {
        return producto;
    }
    public String getTipo() {
        return tipo;
    }
    public int getCantidad() {
        return cantidad;
    }
    public LocalDateTime getFechaHora() {
        return fechaHora;
    }
    public int getCantidadConSigno() {
        return tipo.equals("Ingreso") ? cantidad : -cantidad;
    }
}